import React, { useMemo } from "react";
import { ThreeCanvas } from "@remotion/three";
import { useThree } from "@react-three/fiber";
import {
  AbsoluteFill,
  Audio,
  random,
  Sequence,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import {
  ELEV,
  RAIN,
  TRAIN_KINDS,
  STRAP_KINDS,
  STRAP,
  LAND_KINDS,
  LAND,
  TOAST_KINDS,
  TOAST,
  GIANT_KINDS,
  GIANT,
  GIANT_X,
  ELEVPACK,
  BLANKET_KINDS,
  BLANKETS,
  GOLD_GONE,
  GOLD_SIDE,
  TANK,
  BOUNCE_KINDS,
  TINY,
  TINY_KINDS,
  AIR_KINDS,
  HEAVY_KINDS,
  FRICTION_KINDS,
  FRICTION_OFF,
  SLOPE,
  SLOPE_KINDS,
  HitSound,
  SimKind,
  SimResult,
  simulate,
} from "../sim/scenes";
import { fontFamily } from "../theme";

// 物理エンジンで計算した場面を、3D で描く（人は関節つきの人形）

const LANE_COLORS = ["#ff4a3d", "#2f8bff"];
const PARTY_SHIRTS = ["#ff4a3d", "#ffb020", "#2fc46b", "#2f8bff", "#b25cff"];

type Cam = { pos: [number, number, number]; look: [number, number, number] };

// 下の字幕に隠れないよう、カメラの中心を画面の上寄りにずらす（px）
const LIFT = 120;

const setLift = (c: THREE.PerspectiveCamera, width: number, height: number) => {
  c.setViewOffset(width, height + 2 * LIFT, 0, 2 * LIFT, width, height);
};

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

// フレームごとの物体の位置
const posAt = (sim: SimResult, f: number, i: number): [number, number, number] => {
  const o = (Math.min(f, sim.frames - 1) * sim.bodies.length + i) * 7;
  return [sim.data[o], sim.data[o + 1], sim.data[o + 2]];
};

const quatAt = (sim: SimResult, f: number, i: number): [number, number, number, number] => {
  const o = (Math.min(f, sim.frames - 1) * sim.bodies.length + i) * 7;
  return [sim.data[o + 3], sim.data[o + 4], sim.data[o + 5], sim.data[o + 6]];
};

const findIndex = (sim: SimResult, shape: string, lane: number) =>
  sim.bodies.findIndex((b) => b.shape === shape && b.lane === lane);

// 巨人が地面にぶつかった時刻（秒）。カメラのゆれ・土けむりに使う
const giantHit = (sim: SimResult) => {
  const d = sim.values["down1"];
  return d ? d[sim.frames - 1] : -1;
};

// 場面ごとのカメラ（巨人の場面は、ぶつかった瞬間にゆらす）
const cameraFor = (sim: SimResult, f: number, total: number): Cam => {
  const base = cameraBase(sim, f, total);
  if (!GIANT_KINDS.includes(sim.kind)) {
    return base;
  }
  const hitT = giantHit(sim);
  const dt = f / sim.fps - hitT;
  if (hitT < 0 || dt < 0 || dt > 1.2) {
    return base;
  }
  const amp = (sim.kind === "gfallLow" ? 0.55 : sim.kind === "gstand" ? 0.35 : 0.8) * Math.exp(-dt * 5);
  const sx = Math.sin(dt * 47) * amp;
  const sy = Math.sin(dt * 61 + 1) * amp * 0.8;
  return {
    pos: [base.pos[0] + sx, base.pos[1] + sy, base.pos[2]],
    look: [base.look[0] + sx * 0.6, base.look[1] + sy * 0.6, base.look[2]],
  };
};

const cameraBase = (sim: SimResult, f: number, total: number): Cam => {
  const t = f / Math.max(1, total - 1);
  switch (sim.kind) {
    case "scale":
      return { pos: [0, 1.7, lerp(9.0, 8.5, t)], look: [0, 1.15, 0] };
    case "jump":
      return { pos: [0, 2.2, lerp(9.4, 8.8, t)], look: [0, 2.0, 0] };
    case "slip":
      return { pos: [0.9, 1.5, lerp(8.8, 8.2, t)], look: [0.9, 0.85, 0] };
    case "elevfall":
    case "elevfloat":
    case "elevsafe":
      // かごの正面（ドアの位置）から、中を見る。かごといっしょに動く
      return { pos: [0, 1.5, 4.9], look: [0, 1.25, 0] };
    case "rwalk":
    case "rrun": {
      // 歩く・走る人を、横から追いかける
      const pi = sim.bodies.findIndex((b) => b.part === "pelvis");
      const px = Math.min(RAIN.dist - 1.2, posAt(sim, f, pi)[0]);
      return { pos: [px + 0.6, 2.3, 8.6], look: [px + 0.9, 1.45, -0.6] };
    }
    case "bk_silk":
    case "bk_towel":
    case "bk_wool":
    case "bk_down":
    case "bk_weight":
      // ベッドの足もと、ななめ上から（ゆっくり近づく）
      return { pos: [lerp(1.8, 1.65, t), lerp(2.8, 2.6, t), lerp(2.9, 2.65, t)], look: [0, 0.62, -0.35] };
    case "epack":
      // エレベーターの入口の前、少し上から中を見下ろす
      return { pos: [0.45, 7.2, lerp(3.9, 3.7, t)], look: [0.45, 0.0, -0.6] };
    case "gstand":
      // ふつうの人（左）と巨人（右）の全身が入るよう、遠くから
      return { pos: [1.8, 10.5, lerp(62, 60, t)], look: [1.8, 8.2, 0] };
    case "gfall":
      return { pos: [3.0, 10.5, lerp(62, 60, t)], look: [3.0, 8.0, 0] };
    case "gfallLow":
      // 倒れてくる先の地面すれすれから、巨人を見上げる
      return { pos: [lerp(44, 42, t), 1.5, 15], look: [8, 6.5, -1.5] };
    case "tbutter":
    case "tflick":
      // テーブルのふちと、トーストが落ちる床が見えるよう、斜め上から
      return { pos: [0, 3.2, lerp(2.05, 1.95, t)], look: [0, 0.0, 0.08] };
    case "lknee":
    case "lmat":
      // 台・着地する所・2人の全身が入るよう、正面のやや上から
      return { pos: [0, 2.9, lerp(11.6, 11.2, t)], look: [0, 1.75, 0.3] };
    case "strfeet":
    case "strhold":
      // 2人の全身とつり革が入るよう、正面から少し見下ろす
      return { pos: [0, 2.0, lerp(8.0, 7.7, t)], look: [0, 1.05, -0.2] };
    case "trconst":
    case "tracc":
    case "trbrake":
      // 床の印（跳んだ位置・着地した位置）が見えるよう、上から見下ろす
      return { pos: [0, 4.4, lerp(8.4, 8.0, t)], look: [0, 0.3, -0.3] };
    case "gold":
    case "goldgone":
      // 人の後ろから、金の立方体を見上げる
      return { pos: [lerp(-6, 6, t), 6, 95], look: [0, 8, -6] };
    case "ice":
      // 水そうの中が見えるよう、少し上から見下ろす
      return { pos: [0, 2.4, lerp(6.4, 6.0, t)], look: [0, 0.7, 0.2] };
    case "bjump":
      return { pos: [0, 2.6, lerp(11.2, 10.6, t)], look: [0, 2.5, 0] };
    case "bdrop":
      // 卵が落ちる地面が、下の字幕にかからないよう、上から見下ろす
      return { pos: [0.15, 2.3, lerp(5.4, 5.1, t)], look: [0.15, 0.6, 0.3] };
    case "bwall":
      return { pos: [-0.1, 2.9, lerp(11.5, 10.9, t)], look: [-0.1, 2.5, 0] };
    case "tworld": {
      // 大きな物のまわりを、ゆっくり一周する（40秒で一周。simStart で向きを選べる）
      const a = (f / sim.fps) * ((Math.PI * 2) / 40);
      return { pos: [Math.sin(a) * 5.6, 1.8, Math.cos(a) * 5.6], look: [0, 1.15, 0] };
    }
    case "tlift":
      return { pos: [0, 1.75, lerp(7.6, 7.2, t)], look: [0, 1.45, 0] };
    case "tjump":
      return { pos: [0, 5.4, lerp(18.5, 17.5, t)], look: [0, 4.9, 0] };
    case "tfall": {
      const a = lerp(-0.2, 0.2, t);
      return { pos: [Math.sin(a) * 5.8, 6.4, Math.cos(a) * 5.8], look: [0, 2.35, 0] };
    }
    case "twind":
      return { pos: [0.6, 1.8, lerp(10.4, 9.8, t)], look: [0.6, 1.25, 0] };
    case "train":
      return { pos: [0, 1.65, lerp(7.8, 7.4, t)], look: [0, 1.3, 0] };
    case "afeather":
      return { pos: [0, 1.6, lerp(8.2, 7.8, t)], look: [0, 1.6, 0] };
    case "arain":
      return { pos: [0, 1.6, lerp(8.4, 7.9, t)], look: [0, 1.25, 0] };
    case "asky": {
      // 落ちていく2人を、ななめ上からゆっくり回りこんで見る
      const a = lerp(-0.2, 0.2, t);
      return { pos: [Math.sin(a) * 5.8, 6.4, Math.cos(a) * 5.8], look: [0, 2.35, 0] };
    }
    case "throw":
    case "athrow":
    case "aplane": {
      // いちばん遠くまで飛んでいるボールを追いかけて、だんだん引く
      let far = 0;
      const shape = sim.kind === "aplane" ? "plane" : "sphere";
      for (let k = 0; k <= f; k++) {
        for (const lane of [0, 1]) {
          far = Math.max(far, posAt(sim, k, findIndex(sim, shape, lane))[0]);
        }
      }
      const air = sim.kind !== "throw";
      if (air) {
        far = Math.min(far, 9);
      }
      const cx = air ? 0.3 + far * 0.4 : 0.8 + far * 0.5;
      const d = air ? 8 + far * 0.8 : 6.5 + far * 0.55;
      if (air) {
        return { pos: [cx, 1.8 + far * 0.12, d], look: [cx, 0.9 + far * 0.12, 0] };
      }
      return { pos: [cx, 1.8 + far * 0.12, d], look: [cx, 1.6 + far * 0.1, 0] };
    }
    case "tunnel":
    case "tunnelzero": {
      // 落ちていく人を、ななめ上から追いかける
      const pi = sim.bodies.findIndex((b) => b.part === "pelvis");
      const p = posAt(sim, f, pi);
      return { pos: [p[0] + 1.6, p[1] + 2.9, p[2] + 2.9], look: [p[0], p[1] - 0.2, p[2]] };
    }
    case "wind":
      return { pos: [-0.2, 1.7, lerp(9.6, 9.0, t)], look: [-0.2, 1.15, 0] };
    case "hjump":
      // 高さ3mの台と、2人の全身・着地する所が入るよう、正面のやや上から
      return { pos: [0, 4.2, lerp(22.5, 22.0, t)], look: [0, 3.2, 0.3] };
    case "hthrow":
      return { pos: [0.2, 2.4, lerp(11.0, 10.5, t)], look: [0.2, 1.6, -0.2] };
    case "hwind":
    case "hcar":
      // 風に流される人・車が長く見えるよう、遠くから広く
      return { pos: [1.2, 3.6, lerp(19.5, 19.0, t)], look: [1.2, 0.9, -0.2] };
    case "fstand":
      return { pos: [0, 1.5, lerp(8.6, 8.0, t)], look: [0, 0.85, 0] };
    case "fpush":
    case "xpush":
      return { pos: [0.9, 1.9, lerp(10.2, 9.6, t)], look: [0.9, 0.8, 0] };
    case "ladder":
      // 斜め前から見下ろす（手前と奥のはしごが重ならないように）
      return { pos: [lerp(-6.0, -5.4, t), 4.0, 8.2], look: [-0.4, 1.2, -0.3] };
    case "fchaos": {
      const a = lerp(-0.3, 0.3, t);
      return { pos: [Math.sin(a) * 7.6, 2.1, Math.cos(a) * 7.6], look: [0, 1.1, 0] };
    }
    case "xslide":
      return { pos: [0.4, 2.3, lerp(9.6, 9.1, t)], look: [0.4, 1.35, 0] };
    case "slbox":
    case "slfall":
    case "slball": {
      // 横から。坂を下っていく物（奥のレーン）を追いかける。はじめは上の段（平らな地面）も入る
      const bi =
        sim.kind === "slball"
          ? sim.bodies.findIndex((b) => b.shape === "sphere" && b.lane === 1)
          : sim.kind === "slbox"
            ? sim.bodies.findIndex((b) => b.shape === "box" && b.size[0] < 0.5 && b.lane === 1)
            : sim.bodies.findIndex((b) => b.part === "pelvis" && b.lane === 1);
      const bp = posAt(sim, f, bi);
      // はじめは2つの世界が入るよう遠くから。動き出したら、下っていく物に寄っていく
      const tt = f / sim.fps;
      const zoom = Math.min(1, Math.max(0, (tt - 0.8) / 1.6));
      const k = zoom * zoom * (3 - 2 * zoom);
      const dist = 18.4 - 9.5 * k;
      const cx = Math.max(0.6, bp[0] - 1.8 * (1 - k));
      const cy = Math.min(2.6, bp[1] + 1.4 * (1 - k) + 0.3 * k);
      return { pos: [cx, cy + 0.6, dist], look: [cx, cy, 0] };
    }
    case "brake":
    case "fbrake":
    case "xbrake": {
      // 2台の車のまん中を見る（止まれない車は、そのまま画面の外へ走り去る）
      const mid =
        (posAt(sim, f, findIndex(sim, "car", 0))[0] +
          posAt(sim, f, findIndex(sim, "car", 1))[0]) /
        2;
      // 重力が強い世界の車は手前で止まるので、そのときは少し左を見る
      const near = Math.min(
        posAt(sim, f, findIndex(sim, "car", 0))[0],
        posAt(sim, f, findIndex(sim, "car", 1))[0],
      );
      const cx = Math.min(Math.max(-1, mid), 10) + (near > 2.5 ? 2 : 0.8);
      return { pos: [cx - 5, 9, 17], look: [cx + 0.5, 0, 0] };
    }
    default: {
      const a = lerp(-0.35, 0.35, t);
      return {
        pos: [Math.sin(a) * 10.5, 2.6, Math.cos(a) * 10.5],
        look: [0, 2.0, 0],
      };
    }
  }
};

// 3D の点を画面の座標へ（HTML のラベルを物体に合わせて置くため）
const project = (
  cam: Cam,
  p: [number, number, number],
  width: number,
  height: number,
) => {
  const c = new THREE.PerspectiveCamera(40, width / height, 0.1, 500);
  setLift(c, width, height);
  c.position.set(...cam.pos);
  c.lookAt(new THREE.Vector3(...cam.look));
  c.updateMatrixWorld();
  c.updateProjectionMatrix();
  const v = new THREE.Vector3(...p).project(c);
  return { x: (v.x * 0.5 + 0.5) * width, y: (-v.y * 0.5 + 0.5) * height };
};

const CameraRig: React.FC<{ cam: Cam; width: number; height: number }> = ({
  cam,
  width,
  height,
}) => {
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera;
  setLift(camera, width, height);
  camera.position.set(...cam.pos);
  camera.lookAt(new THREE.Vector3(...cam.look));
  camera.updateProjectionMatrix();
  return null;
};

// 地面の模様（1m ごとのタイル。動きや距離が分かるように）
const useGroundTexture = (kind: SimKind) =>
  useMemo(() => {
    const size = 256;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d")!;
    if (kind === "rwalk" || kind === "rrun") {
      // ぬれたアスファルト
      ctx.fillStyle = "#3d4249";
      ctx.fillRect(0, 0, size, size);
      for (let i = 0; i < 2200; i++) {
        const g = 55 + ((i * 97) % 35);
        ctx.fillStyle = `rgb(${g},${g + 3},${g + 8})`;
        ctx.fillRect((i * 53) % size, (i * 131) % size, 2, 2);
      }
    } else if (TRAIN_KINDS.includes(kind) || STRAP_KINDS.includes(kind)) {
      // 電車の床（灰色のゴムの床に、細かい粒）
      ctx.fillStyle = "#8e959e";
      ctx.fillRect(0, 0, size, size);
      for (let i = 0; i < 1400; i++) {
        const g = 120 + ((i * 97) % 40);
        ctx.fillStyle = `rgb(${g},${g + 4},${g + 10})`;
        ctx.fillRect((i * 53) % size, (i * 131) % size, 2, 2);
      }
    } else if (TINY_KINDS.includes(kind) || TOAST_KINDS.includes(kind) || BLANKET_KINDS.includes(kind)) {
      // 木の床（板の幅は 10cmの人の世界で 10cm → 拡大して 1.75m）
      const plank = ["#b98a5a", "#c49464", "#ae8052", "#bf8f5d"];
      plank.forEach((c, i) => {
        ctx.fillStyle = c;
        ctx.fillRect(0, (i * size) / 4, size, size / 4);
        ctx.fillStyle = "rgba(60,35,15,0.55)";
        ctx.fillRect(0, (i * size) / 4, size, 2);
      });
      for (let i = 0; i < 260; i++) {
        ctx.fillStyle = `rgba(90,55,25,${0.08 + ((i * 37) % 10) / 100})`;
        ctx.fillRect((i * 53) % size, (i * 131) % size, 30 + ((i * 17) % 40), 1);
      }
    } else if (kind === "brake" || kind === "fbrake" || kind === "xbrake") {
      ctx.fillStyle = "#4a4d55";
      ctx.fillRect(0, 0, size, size);
      for (let i = 0; i < 1800; i++) {
        const g = 60 + ((i * 97) % 40);
        ctx.fillStyle = `rgb(${g},${g + 2},${g + 8})`;
        ctx.fillRect((i * 53) % size, (i * 131) % size, 2, 2);
      }
    } else {
      ctx.fillStyle = "#8cc965";
      ctx.fillRect(0, 0, size, size);
      ctx.fillStyle = "#80bd5a";
      ctx.fillRect(0, 0, size / 2, size / 2);
      ctx.fillRect(size / 2, size / 2, size / 2, size / 2);
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.colorSpace = THREE.SRGBColorSpace;
    // brake は 4m、それ以外は 2m（タイル1枚が1m）ごとにくり返す
    const unit = TINY_KINDS.includes(kind) ? 7 : kind === "brake" || kind === "fbrake" || kind === "xbrake" ? 4 : 2;
    tex.repeat.set(200 / unit, 200 / unit);
    tex.anisotropy = 8;
    return tex;
  }, [kind]);

// 目盛り（ジャンプの高さ・投げた距離）
const useRulerTexture = (labels: string[], vertical: boolean) =>
  useMemo(() => {
    const canvas = document.createElement("canvas");
    const n = labels.length - 1;
    canvas.width = vertical ? 160 : 128 * n;
    canvas.height = vertical ? 128 * n : 160;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#222";
    ctx.font = "bold 44px sans-serif";
    labels.forEach((label, i) => {
      if (vertical) {
        const y = canvas.height - (i / n) * canvas.height;
        ctx.fillRect(0, Math.min(canvas.height - 6, Math.max(0, y - 3)), 70, 6);
        if (label) {
          ctx.fillText(label, 76, Math.min(canvas.height - 6, Math.max(40, y + 16)));
        }
      } else {
        const x = (i / n) * canvas.width;
        ctx.fillRect(Math.min(canvas.width - 6, Math.max(0, x - 3)), 0, 6, 70);
        if (label) {
          ctx.fillText(label, Math.min(canvas.width - 70, Math.max(4, x - 20)), 130);
        }
      }
    });
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return tex;
  }, [labels, vertical]);

// 効果音の種類ごとの最大音量と、最大になるぶつかる速さ（m/s）
const HIT_SOUNDS: Record<HitSound, { file: string; max: number; ref: number }> = {
  body: { file: "sfx/thud1.wav", max: 0.3, ref: 5 },
  ball: { file: "sfx/tok.wav", max: 0.22, ref: 9 },
  cone: { file: "sfx/clack.wav", max: 0.25, ref: 6 },
};

const SKIN = "#f1c7a0";
const PANTS = "#2d3a57";
const SHOE = "#2a2a2e";
const HAIR = "#3a2a20";

const partGeometry = (part: string, size: [number, number, number]) => {
  const [w, h, d] = size;
  if (part === "head") {
    return new THREE.SphereGeometry(w / 2, 32, 24);
  }
  if (/upperArm|lowerArm|thigh|shin/.test(part)) {
    const r = Math.min(w, d) / 2;
    return new THREE.CapsuleGeometry(r, Math.max(0.01, h - 2 * r), 8, 16);
  }
  return new RoundedBoxGeometry(w, h, d, 4, Math.min(w, h, d) * 0.35);
};

// 地球を貫く穴の壁：岩の地層の模様と、一定の間隔の明かり。壁は落ちる人のまわりにだけ描き、
// 模様の位置を高さに合わせてずらして、ずっと続く穴に見せる
const useRockTexture = () =>
  useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext("2d")!;
    let y = 0;
    let k = 0;
    while (y < 512) {
      const h = 8 + ((k * 37) % 29);
      const c = 70 + ((k * 53) % 60);
      ctx.fillStyle = `rgb(${c + 40},${c},${Math.round(c * 0.6)})`;
      ctx.fillRect(0, y, 256, h);
      y += h;
      k++;
    }
    for (let i = 0; i < 1500; i++) {
      const g = (i * 71) % 90;
      ctx.fillStyle = `rgba(${g + 20},${g},${g * 0.5},0.5)`;
      ctx.fillRect((i * 97) % 256, (i * 151) % 512, 3, 2);
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.repeat.set(4, 6);
    return tex;
  }, []);

// y：壁を置く高さ（落ちる人のまわり）、phase：模様を流す量（m）。人がその場にいても、壁が流れて速さが見える
const Shaft: React.FC<{ y: number; phase?: number }> = ({ y, phase = 0 }) => {
  const tex = useRockTexture();
  const H = 60;
  const yy = y - phase;
  // 模様の1回分が10m。壁の中心が y にあっても、模様は高さで決まる位置に見える
  tex.offset.y = (((yy - H / 2) / 10) % 1 + 1) % 1;
  const lamps = [];
  for (let h = Math.ceil((yy - 28) / 6) * 6; h < yy + 28; h += 6) {
    lamps.push(h + phase);
  }
  return (
    <group>
      <mesh position={[0, y, 0]}>
        <cylinderGeometry args={[2.8, 2.8, H, 48, 1, true]} />
        <meshStandardMaterial map={tex} side={THREE.BackSide} roughness={0.95} />
      </mesh>
      {lamps.map((h) => (
        <mesh key={h} position={[0, h, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.72, 0.05, 8, 64]} />
          <meshStandardMaterial color="#ffb347" emissive="#ff9a2e" emissiveIntensity={2.5} />
        </mesh>
      ))}
    </group>
  );
};

// 羽根（白い羽根と、まん中の軸）
const Feather: React.FC = () => (
  // 小さくて見えにくいので、見た目は2倍にする
  <group scale={2}>
    <mesh rotation={[-Math.PI / 2, 0, 0]} scale={[0.032, 0.105, 1]} castShadow>
      <circleGeometry args={[1, 32]} />
      <meshStandardMaterial color="#fbfbf6" roughness={0.9} side={THREE.DoubleSide} />
    </mesh>
    <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 0.003, 0.01]}>
      <cylinderGeometry args={[0.003, 0.002, 0.24, 6]} />
      <meshStandardMaterial color="#c9b9a0" roughness={0.6} />
    </mesh>
  </group>
);

// 紙ひこうき（機首が +x）
const usePlaneGeometry = () =>
  useMemo(() => {
    const g = new THREE.BufferGeometry();
    const v = [
      // 左の翼
      0.14, 0.0, 0.0, -0.13, 0.01, -0.1, -0.13, 0.0, 0.0,
      // 右の翼
      0.14, 0.0, 0.0, -0.13, 0.0, 0.0, -0.13, 0.01, 0.1,
      // 胴（下に折った部分）
      0.14, 0.0, 0.0, -0.13, 0.0, 0.0, -0.13, -0.045, 0.0,
    ];
    g.setAttribute("position", new THREE.Float32BufferAttribute(v, 3));
    g.computeVertexNormals();
    return g;
  }, []);

const PaperPlane: React.FC<{ color: string }> = ({ color }) => {
  const geom = usePlaneGeometry();
  return (
    <mesh geometry={geom} castShadow scale={2.2}>
      <meshStandardMaterial color={color} roughness={0.8} side={THREE.DoubleSide} />
    </mesh>
  );
};

// ビーチボールのしま模様
const useBeachTexture = () =>
  useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 512;
    canvas.height = 256;
    const ctx = canvas.getContext("2d")!;
    const colors = ["#ff3b3b", "#ffffff", "#ffd21a", "#ffffff", "#2f8bff", "#ffffff"];
    colors.forEach((c, i) => {
      ctx.fillStyle = c;
      ctx.fillRect((i * 512) / colors.length, 0, 512 / colors.length + 1, 256);
    });
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, 512, 18);
    ctx.fillRect(0, 238, 512, 18);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);

// 500円玉（10cmの人の世界を17.5倍に拡大：直径46cm・厚さ3.2cm）
const Coin: React.FC<{ y?: number; rot?: number }> = ({ y = 0, rot = 0 }) => (
  <group position={[0, y, 0]} rotation={[0, rot, 0]}>
    <mesh castShadow receiveShadow>
      <cylinderGeometry args={[0.23, 0.23, 0.032, 48]} />
      {/* 金属らしさを強くすると、映りこむ景色がないので黒っぽくなる。少しおさえて明るい金色に */}
      <meshStandardMaterial color="#e3bf63" roughness={0.38} metalness={0.35} />
    </mesh>
    {/* ふちの模様と、表面の円 */}
    <mesh position={[0, 0.0165, 0]} rotation={[-Math.PI / 2, 0, 0]}>
      <ringGeometry args={[0.19, 0.205, 48]} />
      <meshStandardMaterial color="#b8923f" roughness={0.45} metalness={0.35} />
    </mesh>
  </group>
);

// 10cmの人のまわりの物（17.5倍に拡大して置く）。label はラベルを出す位置
const TINY_PROPS: { name: string; label: [number, number, number] }[] = [
  { name: "500円玉（直径46cm）", label: [1.7, 0.75, -0.3] },
  { name: "鉛筆（長さ3m）", label: [-0.2, 0.45, -1.7] },
  { name: "スマホ（高さ2.6m）", label: [-2.0, 2.9, -0.4] },
  { name: "米つぶ（9cm）", label: [0.9, 0.35, 1.2] },
];

const TinyProps: React.FC = () => (
  <group>
    {/* 立てた500円玉 */}
    <group position={[1.7, 0.23, -0.3]} rotation={[Math.PI / 2, 0, -0.35]}>
      <Coin />
    </group>
    {/* 寝かせた鉛筆（六角形・長さ3m・太さ12cm） */}
    <group position={[-0.2, 0.06, -1.7]} rotation={[0, 0.15, Math.PI / 2]}>
      <mesh castShadow receiveShadow>
        <cylinderGeometry args={[0.06, 0.06, 2.6, 6]} />
        <meshStandardMaterial color="#f2c230" roughness={0.5} />
      </mesh>
      <mesh position={[0, -1.5, 0]} rotation={[Math.PI, 0, 0]} castShadow>
        <cylinderGeometry args={[0.06, 0.012, 0.4, 6]} />
        <meshStandardMaterial color="#e7cfa6" roughness={0.8} />
      </mesh>
      <mesh position={[0, -1.72, 0]} rotation={[Math.PI, 0, 0]}>
        <coneGeometry args={[0.012, 0.05, 6]} />
        <meshStandardMaterial color="#333" roughness={0.6} />
      </mesh>
      <mesh position={[0, 1.36, 0]} castShadow>
        <cylinderGeometry args={[0.062, 0.062, 0.12, 16]} />
        <meshStandardMaterial color="#c9ccd2" roughness={0.3} metalness={0.7} />
      </mesh>
      <mesh position={[0, 1.5, 0]} castShadow>
        <cylinderGeometry args={[0.058, 0.058, 0.16, 16]} />
        <meshStandardMaterial color="#f08aa0" roughness={0.8} />
      </mesh>
    </group>
    {/* 立てたスマホ（高さ2.6m・幅1.25m・厚さ14cm） */}
    <group position={[-2.0, 1.31, -0.4]} rotation={[0, 0.5, 0]}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[1.25, 2.62, 0.14]} />
        <meshStandardMaterial color="#15171c" roughness={0.25} metalness={0.4} />
      </mesh>
      <mesh position={[0, 0, 0.071]}>
        <planeGeometry args={[1.12, 2.45]} />
        <meshStandardMaterial color="#1f3a66" emissive="#2a5aa8" emissiveIntensity={0.35} roughness={0.1} />
      </mesh>
    </group>
    {/* 米つぶ（長さ5mm → 9cm） */}
    {[[0.9, 1.2, 0.3], [1.05, 1.35, 1.2], [0.75, 1.4, 2.1]].map(([x, z, r], k) => (
      <mesh key={k} position={[x, 0.025, z]} rotation={[0, r, Math.PI / 2]} scale={[1, 1, 0.75]} castShadow>
        <capsuleGeometry args={[0.025, 0.045, 6, 12]} />
        <meshStandardMaterial color="#fbf8ef" roughness={0.6} />
      </mesh>
    ))}
  </group>
);

// トランポリンの地面：人や物が沈んだ所が、まわりごとへこむマット
const TrampMat: React.FC<{
  sim: SimResult;
  f: number;
  lane: number;
  area: [number, number, number, number];
}> = ({ sim, f, lane, area }) => {
  const [cx, cz, w, d] = area;
  const tex = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#1b2433";
    ctx.fillRect(0, 0, 256, 256);
    ctx.strokeStyle = "rgba(120,150,200,0.25)";
    ctx.lineWidth = 2;
    for (let i = 0; i <= 256; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 256);
      ctx.moveTo(0, i);
      ctx.lineTo(256, i);
      ctx.stroke();
    }
    const t = new THREE.CanvasTexture(canvas);
    t.wrapS = THREE.RepeatWrapping;
    t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(w, d);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [w, d]);
  // その瞬間に沈んでいる所（人の部位・卵）
  const dents: [number, number, number][] = [];
  sim.bodies.forEach((b, i) => {
    if (b.lane !== lane || !(b.shape === "part" || b.shape === "egg")) {
      return;
    }
    const p = posAt(sim, f, i);
    const low = p[1] - b.size[1] / 2;
    if (low < 0) {
      dents.push([p[0], p[2], -low]);
    }
  });
  const geom = useMemo(() => new THREE.PlaneGeometry(w, d, Math.round(w * 10), Math.round(d * 10)), [w, d]);
  const pos = geom.attributes.position as THREE.BufferAttribute;
  for (let k = 0; k < pos.count; k++) {
    // 平面の (x, y) は、地面では (x, -z)
    const x = pos.getX(k) + cx;
    const z = -pos.getY(k) + cz;
    let dip = 0;
    for (const [dx, dz, dd] of dents) {
      const r2 = (x - dx) ** 2 + (z - dz) ** 2;
      dip = Math.max(dip, dd * Math.exp(-r2 / (2 * 0.5 * 0.5)));
    }
    pos.setZ(k, 0.004 - dip);
  }
  pos.needsUpdate = true;
  geom.computeVertexNormals();
  return (
    <group>
      <mesh geometry={geom} position={[cx, 0, cz]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <meshStandardMaterial map={tex} roughness={0.85} side={THREE.DoubleSide} />
      </mesh>
      {/* まわりのふち（青いクッション） */}
      {[
        [cx, cz - d / 2, w + 0.3, 0.3],
        [cx, cz + d / 2, w + 0.3, 0.3],
        [cx - w / 2, cz, 0.3, d],
        [cx + w / 2, cz, 0.3, d],
      ].map(([x, z, ww, dd], k) => (
        <mesh key={k} position={[x, 0.06, z]} castShadow receiveShadow>
          <boxGeometry args={[ww, 0.12, dd]} />
          <meshStandardMaterial color="#2f7bff" roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
};

// トランポリンではねた瞬間（マットに沈み始めた瞬間）の「ボヨン」と、卵が割れた「グシャ」。
// 音量は、そのあといちばん深く沈んだ深さで決める
const BounceSounds: React.FC<{ sim: SimResult; offset: number }> = ({ sim, offset }) => {
  const deep = sim.values.deep1;
  const out: React.ReactNode[] = [];
  if (deep) {
    for (let k = 1; k < sim.frames; k++) {
      if (deep[k - 1] < 0.03 && deep[k] >= 0.03 && k >= offset) {
        let mx = 0;
        for (let j = k; j < Math.min(sim.frames, k + 12); j++) {
          mx = Math.max(mx, deep[j]);
        }
        out.push(
          <Sequence key={`bo${k}`} from={k - offset} durationInFrames={20}>
            <Audio src={staticFile("sfx/boing.wav")} volume={Math.min(0.3, 0.08 + mx * 0.5)} />
          </Sequence>,
        );
      }
    }
  }
  const br = sim.values.broken0;
  if (br) {
    const k = br.findIndex((x) => x > 0);
    if (k >= offset) {
      out.push(
        <Sequence key="crack" from={k - offset} durationInFrames={20}>
          <Audio src={staticFile("sfx/crack.wav")} volume={0.28} />
        </Sequence>,
      );
    }
  }
  return <>{out}</>;
};

// 生卵（割れたら、黄身と白身と殻のかけら）
const Egg: React.FC<{ broken: boolean }> = ({ broken }) =>
  broken ? (
    <group position={[0, -0.008, 0]} scale={1.6}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} scale={[1.4, 1, 1]}>
        <circleGeometry args={[0.09, 32]} />
        <meshStandardMaterial color="#f4f1e6" roughness={0.2} transparent opacity={0.9} />
      </mesh>
      <mesh position={[0.01, 0.006, 0]} scale={[1, 0.35, 1]}>
        <sphereGeometry args={[0.032, 24, 16]} />
        <meshStandardMaterial color="#ffb21f" roughness={0.25} />
      </mesh>
      {[0, 1, 2, 3, 4].map((k) => (
        <mesh key={k} position={[Math.cos(k * 1.3) * 0.1, 0.006, Math.sin(k * 1.3) * 0.07]} rotation={[k, k * 2, 0]}>
          <boxGeometry args={[0.025, 0.004, 0.018]} />
          <meshStandardMaterial color="#f3e6cf" roughness={0.6} />
        </mesh>
      ))}
    </group>
  ) : (
    // 小さくて見えにくいので、見た目は1.8倍にする
    <mesh scale={[1.8, 2.3, 1.8]} castShadow>
      <sphereGeometry args={[0.035, 24, 18]} />
      <meshStandardMaterial color="#f3e6cf" roughness={0.45} />
    </mesh>
  );

// 金の延べ棒を積み上げた模様（1本 約25cm × 8cm）
const useGoldTexture = () =>
  useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#e7b53c";
    ctx.fillRect(0, 0, 512, 512);
    const bw = 64;
    const bh = 22;
    for (let r = 0; r < 512 / bh; r++) {
      for (let c = -1; c < 512 / bw + 1; c++) {
        const x = c * bw + (r % 2) * (bw / 2);
        const y = r * bh;
        const g = ctx.createLinearGradient(x, y, x, y + bh);
        g.addColorStop(0, "#ffe9a3");
        g.addColorStop(0.45, "#f2c14e");
        g.addColorStop(1, "#b9852a");
        ctx.fillStyle = g;
        ctx.fillRect(x + 2, y + 2, bw - 4, bh - 4);
      }
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(GOLD_SIDE / 2, GOLD_SIDE / 2);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    return tex;
  }, []);

const GoldCube: React.FC<{ gone: number; t: number }> = ({ gone, t }) => {
  const tex = useGoldTexture();
  const s = 1 - gone;
  const c: [number, number, number] = [0, GOLD_SIDE / 2, -GOLD_SIDE / 2 - 1];
  return (
    <group>
      {s > 0.01 ? (
        <mesh position={[c[0], (GOLD_SIDE / 2) * s, c[2]]} scale={[s, s, s]} castShadow receiveShadow>
          <boxGeometry args={[GOLD_SIDE, GOLD_SIDE, GOLD_SIDE]} />
          <meshStandardMaterial map={tex} roughness={0.32} metalness={0.45} emissive="#7a5200" emissiveIntensity={0.55} />
        </mesh>
      ) : null}
      {/* 消えるときのきらきら */}
      {gone > 0 && gone < 1
        ? Array.from({ length: 70 }, (_, i) => {
            const a = random(`ga${i}`) * Math.PI * 2;
            const r = random(`gr${i}`) * GOLD_SIDE * 0.6;
            const up = gone * (6 + random(`gu${i}`) * 14);
            return (
              <mesh key={i} position={[c[0] + Math.cos(a) * r, 2 + random(`gy${i}`) * GOLD_SIDE * 0.8 + up, c[2] + Math.sin(a) * r]}>
                <octahedronGeometry args={[0.35 + 0.3 * Math.sin(t * 9 + i), 0]} />
                <meshBasicMaterial color="#fff2a8" transparent opacity={1 - gone} />
              </mesh>
            );
          })
        : null}
    </group>
  );
};

// エレベーターのかご（前は開いている）と、まわりの昇降路。昇降路のかべは、かごが落ちた距離だけ上へ流れる
const ElevatorCar: React.FC<{ fall: number; snapped: boolean; t: number }> = ({ fall, snapped, t }) => {
  const shaft = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#6b6f76";
    ctx.fillRect(0, 0, 256, 512);
    for (let i = 0; i < 900; i++) {
      const g = 90 + ((i * 97) % 40);
      ctx.fillStyle = `rgb(${g},${g + 2},${g + 6})`;
      ctx.fillRect((i * 53) % 256, (i * 131) % 512, 3, 3);
    }
    // 各階の床（3.3m ごと）
    ctx.fillStyle = "#2b2e33";
    ctx.fillRect(0, 0, 256, 40);
    ctx.fillStyle = "#ffcf33";
    ctx.fillRect(0, 40, 256, 8);
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);
  const H = 12;
  const tex = useMemo(() => {
    const c = shaft.clone();
    c.repeat.set(1, H / 3.3);
    return c;
  }, [shaft]);
  tex.offset.y = (((-fall / 3.3) % 1) + 1) % 1;
  tex.needsUpdate = true;
  const wall = "#cfd5dc";
  return (
    <group>
      {/* 昇降路のかべ（左右と奥） */}
      {[-1.9, 1.9].map((x) => (
        <mesh key={x} position={[x, 1.5, -0.4]} rotation={[0, x < 0 ? Math.PI / 2 : -Math.PI / 2, 0]}>
          <planeGeometry args={[3.2, H]} />
          <meshStandardMaterial map={tex} roughness={0.9} />
        </mesh>
      ))}
      <mesh position={[0, 1.5, -1.6]}>
        <planeGeometry args={[3.8, H]} />
        <meshStandardMaterial map={tex} roughness={0.9} />
      </mesh>
      {/* かご：床・天井・かべ */}
      <mesh position={[0, -0.05, 0]} receiveShadow>
        <boxGeometry args={[2.2, 0.1, 1.8]} />
        <meshStandardMaterial color="#8a7a66" roughness={0.8} />
      </mesh>
      <mesh position={[0, 2.5, 0]}>
        <boxGeometry args={[2.2, 0.1, 1.8]} />
        <meshStandardMaterial color="#e8ebef" emissive="#fff6dd" emissiveIntensity={0.35} />
      </mesh>
      {[-1.1, 1.1].map((x) => (
        <mesh key={x} position={[x, 1.25, 0]} receiveShadow>
          <boxGeometry args={[0.06, 2.5, 1.8]} />
          <meshStandardMaterial color={wall} roughness={0.35} metalness={0.3} />
        </mesh>
      ))}
      <mesh position={[0, 1.25, -0.9]} receiveShadow>
        <boxGeometry args={[2.2, 2.5, 0.06]} />
        <meshStandardMaterial color={wall} roughness={0.35} metalness={0.3} />
      </mesh>
      {/* 手すりと、ボタン */}
      <mesh position={[0, 0.9, -0.82]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.025, 0.025, 1.8, 10]} />
        <meshStandardMaterial color="#d8dde4" metalness={0.7} roughness={0.25} />
      </mesh>
      <mesh position={[1.06, 1.2, 0.5]}>
        <boxGeometry args={[0.04, 0.5, 0.18]} />
        <meshStandardMaterial color="#333" />
      </mesh>
      {/* ロープ（切れると、短くなってゆれる） */}
      {snapped ? (
        <mesh position={[0.05 * Math.sin(t * 7), 3.0, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 0.9, 8]} />
          <meshStandardMaterial color="#555" />
        </mesh>
      ) : (
        <mesh position={[0, 6.6, 0]}>
          <cylinderGeometry args={[0.03, 0.03, 8, 8]} />
          <meshStandardMaterial color="#555" />
        </mesh>
      )}
      <pointLight position={[0, 2.2, 0.3]} intensity={6} distance={6} color="#fff3d6" />
    </group>
  );
};

// 雨の道：スタートの線、10m先のコンビニ、降る雨と、人に当たってはじける雨
const RainStreet: React.FC<{ sim: SimResult; f: number }> = ({ sim, f }) => {
  const t = f / sim.fps;
  const pi = sim.bodies.findIndex((b) => b.part === "pelvis");
  const hi = sim.bodies.findIndex((b) => b.part === "head");
  const p = posAt(sim, f, pi);
  const head = posAt(sim, f, hi);
  const sign = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 512;
    canvas.height = 128;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, 512, 128);
    ["#1f8f4e", "#ff8a00", "#2f8bff"].forEach((c, i) => {
      ctx.fillStyle = c;
      ctx.fillRect(0, 96 + i * 10, 512, 10);
    });
    ctx.fillStyle = "#1f8f4e";
    ctx.font = "bold 72px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("コンビニ", 256, 76);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);
  const drops: React.ReactNode[] = [];
  // カメラのまわりだけに雨を描く（ななめのすじ）
  for (let i = 0; i < 220; i++) {
    const x = p[0] - 4 + random(`rx${i}`) * 9;
    const z = -2.5 + random(`rz${i}`) * 5;
    const H = 6;
    const y = H - ((random(`ry${i}`) * H + t * RAIN.fall) % H);
    drops.push(
      <mesh key={`d${i}`} position={[x, y + 0.15, z]}>
        <boxGeometry args={[0.008, 0.3, 0.008]} />
        <meshBasicMaterial color="#cfe6ff" transparent opacity={0.6} />
      </mesh>,
    );
  }
  // 頭・肩・体の前ではじける雨（当たる量に合わせて数を変える）
  const rate = sim.values.hits[Math.min(sim.frames - 1, f + 1)] - sim.values.hits[f];
  const nSplash = Math.min(16, Math.round(rate / 12));
  for (let i = 0; i < nSplash; i++) {
    const seed = `sp${f}-${i}`;
    const onTop = random(`${seed}t`) < 0.5;
    const x = onTop ? head[0] + (random(`${seed}x`) - 0.5) * 0.4 : p[0] + 0.15;
    const y = onTop ? head[1] + 0.1 - random(`${seed}y`) * 0.3 : 0.3 + random(`${seed}y`) * 1.3;
    drops.push(
      <mesh key={`s${i}`} position={[x, y, (random(`${seed}z`) - 0.5) * 0.4]}>
        <sphereGeometry args={[0.025, 6, 6]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0.85} />
      </mesh>,
    );
  }
  return (
    <group>
      {/* スタートの線 */}
      <mesh position={[0.3, 0.006, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.1, 3]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>
      {/* コンビニ（10m先） */}
      {/* 道の奥に建つ。入り口は人が着く場所（10m）の正面 */}
      <group position={[RAIN.dist + 0.4, 0, -2.9]}>
        <mesh position={[0, 1.6, 0]} castShadow receiveShadow>
          <boxGeometry args={[5, 3.2, 3]} />
          <meshStandardMaterial color="#e8e6e0" roughness={0.8} />
        </mesh>
        <mesh position={[0, 2.75, 1.51]}>
          <planeGeometry args={[3.2, 0.8]} />
          <meshBasicMaterial map={sign} />
        </mesh>
        <mesh position={[-0.4, 1.1, 1.51]}>
          <planeGeometry args={[1.6, 2.0]} />
          <meshStandardMaterial color="#fff6d8" emissive="#fff1c0" emissiveIntensity={0.8} />
        </mesh>
      </group>
      {drops}
    </group>
  );
};

// 電車の外の景色（電柱と建物）。電車が進んだ距離だけ、横に流す
const useSceneryTexture = () =>
  useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 1024;
    canvas.height = 256;
    const ctx = canvas.getContext("2d")!;
    const sky = ctx.createLinearGradient(0, 0, 0, 256);
    sky.addColorStop(0, "#6fb3ff");
    sky.addColorStop(1, "#d8ecff");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, 1024, 256);
    for (let i = 0; i < 14; i++) {
      const w = 50 + ((i * 37) % 60);
      const h = 60 + ((i * 53) % 110);
      ctx.fillStyle = ["#9aa8b8", "#b9c3cf", "#8a97a8", "#c7b9a8"][i % 4];
      ctx.fillRect(i * 75, 200 - h, w, h);
    }
    ctx.fillStyle = "#6c9a4e";
    ctx.fillRect(0, 196, 1024, 60);
    for (let i = 0; i < 4; i++) {
      ctx.fillStyle = "#4a4f57";
      ctx.fillRect(i * 256 + 120, 20, 10, 200);
      ctx.fillRect(i * 256 + 100, 40, 50, 6);
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);

// 電車の車内（後ろのかべと窓、つり革）。窓の外の景色は、電車の進んだ距離 pos だけ流れる
const TrainCar: React.FC<{ x0: number; pos: number; grip?: [number, number, number] | null }> = ({ x0, pos, grip }) => {
  const base = useSceneryTexture();
  const tex = useMemo(() => base.clone(), [base]);
  // 景色の1枚は横 40m 分（電柱 10m おき）
  tex.repeat.set(2.7 / 40, 1);
  tex.offset.x = (((pos / 40) % 1) + 1) % 1;
  tex.needsUpdate = true;
  const W = 2.7;
  return (
    <group>
      {/* 窓の外の景色 */}
      <mesh position={[x0, 1.45, -1.25]}>
        <planeGeometry args={[W, 0.9]} />
        <meshBasicMaterial map={tex} />
      </mesh>
      {/* かべ（窓の下・上・窓わく） */}
      <mesh position={[x0, 0.5, -1.15]} receiveShadow>
        <boxGeometry args={[W, 1.0, 0.1]} />
        <meshStandardMaterial color="#d9dee6" roughness={0.7} />
      </mesh>
      <mesh position={[x0, 2.2, -1.15]}>
        <boxGeometry args={[W, 0.6, 0.1]} />
        <meshStandardMaterial color="#d9dee6" roughness={0.7} />
      </mesh>
      {[-W / 2, 0, W / 2].map((dx) => (
        <mesh key={dx} position={[x0 + dx, 1.45, -1.13]}>
          <boxGeometry args={[0.08, 0.9, 0.12]} />
          <meshStandardMaterial color="#b8c0cc" roughness={0.5} />
        </mesh>
      ))}
      {/* 座席 */}
      <mesh position={[x0, 0.25, -0.85]} castShadow receiveShadow>
        <boxGeometry args={[W - 0.2, 0.45, 0.5]} />
        <meshStandardMaterial color="#3f6fb5" roughness={0.9} />
      </mesh>
      {/* つり革 */}
      <mesh position={[x0, 2.3, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.02, 0.02, W, 8]} />
        <meshStandardMaterial color="#c9ccd2" metalness={0.6} roughness={0.3} />
      </mesh>
      {[-0.9, 0.9].map((dx) => (
        <group key={dx} position={[x0 + dx, 2.3, 0]}>
          <mesh position={[0, -0.15, 0]}>
            <boxGeometry args={[0.03, 0.3, 0.02]} />
            <meshStandardMaterial color="#e8e8e8" />
          </mesh>
          <mesh position={[0, -0.36, 0]}>
            <torusGeometry args={[0.07, 0.015, 8, 20]} />
            <meshStandardMaterial color="#f2f2f2" />
          </mesh>
        </group>
      ))}
      {/* 人がつかんでいるつり革（手の位置まで下がっている） */}
      {grip ? (
        <group position={[grip[0], 0, grip[2]]}>
          {/* 手が輪の下側をにぎる */}
          <mesh position={[0, (2.3 + grip[1] + 0.1) / 2, 0]}>
            <boxGeometry args={[0.035, Math.max(0.02, 2.3 - grip[1] - 0.1), 0.025]} />
            <meshStandardMaterial color="#e8e8e8" />
          </mesh>
          <mesh position={[0, grip[1] + 0.03, 0]}>
            <torusGeometry args={[0.075, 0.018, 8, 24]} />
            <meshStandardMaterial color="#ffd23a" />
          </mesh>
        </group>
      ) : null}
    </group>
  );
};

export const PersonPart: React.FC<{
  part: string;
  size: [number, number, number];
  color: string;
  pos: [number, number, number];
  quat: [number, number, number, number];
  closed?: boolean;
}> = ({ part, size, color, pos, quat, closed }) => {
  const geom = useMemo(() => partGeometry(part, size), [part, size]);
  return (
    <group position={pos} quaternion={quat}>
      <mesh geometry={geom} castShadow receiveShadow>
        <meshStandardMaterial color={color} roughness={0.55} />
      </mesh>
      {part === "head" ? (
        <>
          {/* 髪 */}
          <mesh rotation={[-0.35, 0, 0]} castShadow>
            <sphereGeometry args={[size[0] / 2 + 0.008, 32, 16, 0, Math.PI * 2, 0, Math.PI * 0.42]} />
            <meshStandardMaterial color={HAIR} roughness={0.8} />
          </mesh>
          {/* 目（眠っているときは、閉じた目＝横線） */}
          {[-1, 1].map((s) =>
            closed ? (
              <mesh key={s} position={[s * 0.042, 0.004, size[0] / 2 - 0.004]} rotation={[0, 0, Math.PI / 2]}>
                <capsuleGeometry args={[0.005, 0.026, 4, 8]} />
                <meshStandardMaterial color="#222" roughness={0.5} />
              </mesh>
            ) : (
              <mesh key={s} position={[s * 0.042, 0.01, size[0] / 2 - 0.012]}>
                <sphereGeometry args={[0.017, 12, 12]} />
                <meshStandardMaterial color="#111" roughness={0.3} />
              </mesh>
            ),
          )}
        </>
      ) : null}
    </group>
  );
};

const Car: React.FC<{ color: string }> = ({ color }) => {
  const body = useMemo(() => new RoundedBoxGeometry(4.0, 0.6, 1.7, 4, 0.18), []);
  const cabin = useMemo(() => new RoundedBoxGeometry(2.2, 0.55, 1.5, 4, 0.2), []);
  return (
    <group>
      <mesh geometry={body} position={[0, -0.12, 0]} castShadow receiveShadow>
        <meshStandardMaterial color={color} roughness={0.35} metalness={0.3} />
      </mesh>
      <mesh geometry={cabin} position={[-0.25, 0.42, 0]} castShadow>
        <meshStandardMaterial color="#1d2a3a" roughness={0.15} metalness={0.5} />
      </mesh>
      {[-1.3, 1.3].map((x) =>
        [-0.78, 0.78].map((z) => (
          <mesh key={`${x}${z}`} position={[x, -0.4, z]} rotation={[Math.PI / 2, 0, 0]} castShadow>
            <cylinderGeometry args={[0.3, 0.3, 0.24, 24]} />
            <meshStandardMaterial color="#151515" roughness={0.9} />
          </mesh>
        )),
      )}
      {[-0.55, 0.55].map((z) => (
        <mesh key={z} position={[2.0, -0.05, z]}>
          <boxGeometry args={[0.04, 0.14, 0.3]} />
          <meshStandardMaterial color="#fff6c8" emissive="#fff6c8" emissiveIntensity={0.8} />
        </mesh>
      ))}
    </group>
  );
};

// 布団の模様（布の種類ごと）
const useClothTexture = (look: string) =>
  useMemo(() => {
    const size = 512;
    const c = document.createElement("canvas");
    c.width = size;
    c.height = size;
    const x = c.getContext("2d")!;
    if (look === "silk") {
      const g = x.createLinearGradient(0, 0, size, size);
      g.addColorStop(0, "#e9d8ff");
      g.addColorStop(0.5, "#f6eeff");
      g.addColorStop(1, "#dcc6fb");
      x.fillStyle = g;
      x.fillRect(0, 0, size, size);
    } else if (look === "towel") {
      for (let i = 0; i < 16; i++) {
        x.fillStyle = i % 2 === 0 ? "#bfe3f5" : "#ffffff";
        x.fillRect(0, (i * size) / 16, size, size / 16);
      }
      for (let i = 0; i < 6000; i++) {
        x.fillStyle = "rgba(0,0,0,0.04)";
        x.fillRect((i * 53) % size, (i * 131) % size, 2, 2);
      }
    } else if (look === "wool") {
      x.fillStyle = "#b9342f";
      x.fillRect(0, 0, size, size);
      x.globalAlpha = 0.55;
      for (let i = 0; i < 8; i++) {
        x.fillStyle = "#1f2f5a";
        x.fillRect((i * size) / 8, 0, size / 24, size);
        x.fillRect(0, (i * size) / 8, size, size / 24);
      }
      x.globalAlpha = 0.35;
      for (let i = 0; i < 8; i++) {
        x.fillStyle = "#f2c94c";
        x.fillRect((i * size) / 8 + size / 16, 0, 4, size);
        x.fillRect(0, (i * size) / 8 + size / 16, size, 4);
      }
      x.globalAlpha = 1;
    } else if (look === "down") {
      x.fillStyle = "#fbfbf7";
      x.fillRect(0, 0, size, size);
      // キルティング（ふくらんだマス目）
      const m = 6;
      for (let i = 0; i < m; i++) {
        for (let j = 0; j < m; j++) {
          const g = x.createRadialGradient((i + 0.5) * (size / m), (j + 0.5) * (size / m), 4, (i + 0.5) * (size / m), (j + 0.5) * (size / m), size / m / 1.3);
          g.addColorStop(0, "#ffffff");
          g.addColorStop(1, "#dcdcd2");
          x.fillStyle = g;
          x.fillRect(i * (size / m), j * (size / m), size / m, size / m);
        }
      }
      x.strokeStyle = "#c8c8bc";
      x.lineWidth = 3;
      for (let i = 0; i <= m; i++) {
        x.beginPath();
        x.moveTo((i * size) / m, 0);
        x.lineTo((i * size) / m, size);
        x.moveTo(0, (i * size) / m);
        x.lineTo(size, (i * size) / m);
        x.stroke();
      }
    } else {
      // 加重ブランケット：グレーの布に、つぶが入った小さなマス
      x.fillStyle = "#6b7280";
      x.fillRect(0, 0, size, size);
      x.strokeStyle = "#4b5260";
      x.lineWidth = 3;
      const m = 12;
      for (let i = 0; i <= m; i++) {
        x.beginPath();
        x.moveTo((i * size) / m, 0);
        x.lineTo((i * size) / m, size);
        x.moveTo(0, (i * size) / m);
        x.lineTo(size, (i * size) / m);
        x.stroke();
      }
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    return t;
  }, [look]);

// 布団（布のシミュレーションの点を、つないで面にする）。厚い布団は、うら側の面を少し下に描いて厚みを出す
const ClothMesh: React.FC<{ sim: SimResult; f: number; look: string }> = ({ sim, f, look }) => {
  const info = sim.values["clothInfo"];
  const data = sim.values["clothData"];
  const nx = info[0];
  const ny = info[1];
  const thick = info[2];
  const n = nx * ny;
  const tex = useClothTexture(look);
  const index = useMemo(() => {
    const idx: number[] = [];
    for (let j = 0; j < ny - 1; j++) {
      for (let i = 0; i < nx - 1; i++) {
        const a = j * nx + i;
        idx.push(a, a + nx, a + 1, a + 1, a + nx, a + nx + 1);
      }
    }
    return idx;
  }, [nx, ny]);
  const uv = useMemo(() => {
    const u = new Float32Array(n * 2);
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        u[(j * nx + i) * 2] = i / (nx - 1);
        u[(j * nx + i) * 2 + 1] = j / (ny - 1);
      }
    }
    return u;
  }, [n, nx, ny]);
  const [top, bottom] = useMemo(() => {
    const pos = data.slice(f * n * 3, (f + 1) * n * 3);
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
    g.setIndex(index);
    g.computeVertexNormals();
    // 上が外側になるよう、法線が下を向いている点はうら返す
    const nrm = g.getAttribute("normal") as THREE.BufferAttribute;
    let sum = 0;
    for (let k = 0; k < n; k++) sum += nrm.getY(k);
    const sign = sum >= 0 ? 1 : -1;
    const pos2 = new Float32Array(pos.length);
    for (let k = 0; k < n; k++) {
      pos2[k * 3] = pos[k * 3] - nrm.getX(k) * thick * sign;
      pos2[k * 3 + 1] = pos[k * 3 + 1] - nrm.getY(k) * thick * sign;
      pos2[k * 3 + 2] = pos[k * 3 + 2] - nrm.getZ(k) * thick * sign;
    }
    const g2 = new THREE.BufferGeometry();
    g2.setAttribute("position", new THREE.BufferAttribute(pos2, 3));
    g2.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
    g2.setIndex(index);
    g2.computeVertexNormals();
    return [g, g2];
  }, [data, f, n, uv, index, thick]);
  const rough = look === "silk" ? 0.28 : look === "weight" ? 0.75 : 0.95;
  const metal = look === "silk" ? 0.18 : 0;
  return (
    <group>
      <mesh geometry={top} castShadow receiveShadow>
        <meshStandardMaterial map={tex} roughness={rough} metalness={metal} side={THREE.DoubleSide} />
      </mesh>
      {thick > 0.015 ? (
        <mesh geometry={bottom} castShadow receiveShadow>
          <meshStandardMaterial map={tex} roughness={rough} metalness={metal} side={THREE.DoubleSide} color="#d8d8d8" />
        </mesh>
      ) : null}
    </group>
  );
};

// 寝室（かべ・ラグ・ナイトテーブル）
const Bedroom: React.FC = () => (
  <group>
    <mesh position={[0, 1.5, -1.25]} receiveShadow>
      <boxGeometry args={[8, 3, 0.1]} />
      <meshStandardMaterial color="#efe6d8" roughness={0.95} />
    </mesh>
    <mesh position={[-3, 1.5, 1]} receiveShadow>
      <boxGeometry args={[0.1, 3, 6]} />
      <meshStandardMaterial color="#f3ebdf" roughness={0.95} />
    </mesh>
    <mesh position={[0, 0.006, 0.4]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <planeGeometry args={[2.4, 3.0]} />
      <meshStandardMaterial color="#c9b79c" roughness={1} />
    </mesh>
    <group position={[-0.95, 0, -0.85]}>
      <mesh position={[0, 0.25, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.45, 0.5, 0.4]} />
        <meshStandardMaterial color="#9c6b46" roughness={0.7} />
      </mesh>
      <mesh position={[0, 0.62, 0]} castShadow>
        <cylinderGeometry args={[0.1, 0.13, 0.24, 20]} />
        <meshStandardMaterial color="#f5e6c4" emissive="#ffcf7a" emissiveIntensity={0.35} />
      </mesh>
    </group>
  </group>
);

// 満員エレベーターのかご（ドアが開いている。かべは断面で、中が見えるように）
const PackElevator: React.FC<{ full: number; t: number }> = ({ full, t }) => {
  const E = ELEVPACK;
  const metal = "#c9ced6";
  const side = (E.w - E.door) / 2;
  // かべは腰の高さまでの「断面」で描く（中のようすが見えるように）
  const WH = 1.0;
  // 満員になったら、ドアが閉まろうとして、人に当たって開く（くり返す）
  const shut = full > 0 && t > full ? Math.abs(Math.sin((t - full) * 2.2)) * 0.22 : 0;
  return (
    <group>
      {/* 床 */}
      <mesh position={[0, 0.006, -E.d / 2]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[E.w, E.d]} />
        <meshStandardMaterial color="#8d8172" roughness={0.8} />
      </mesh>
      {/* 奥の壁と左右の壁 */}
      <mesh position={[0, WH / 2, -E.d - 0.04]} receiveShadow>
        <boxGeometry args={[E.w + 0.16, WH, 0.08]} />
        <meshStandardMaterial color={metal} roughness={0.35} metalness={0.6} />
      </mesh>
      {[-1, 1].map((sx) => (
        <mesh key={sx} position={[sx * (E.w / 2 + 0.04), WH / 2, -E.d / 2]} receiveShadow>
          <boxGeometry args={[0.08, WH, E.d + 0.08]} />
          <meshStandardMaterial color={metal} roughness={0.35} metalness={0.6} />
        </mesh>
      ))}
      {/* 入口のまわり（戸袋）と、開いたドア */}
      {[-1, 1].map((sx) => (
        <group key={`d${sx}`}>
          <mesh position={[sx * (E.door / 2 + side / 2), WH / 2, 0.05]}>
            <boxGeometry args={[side, WH, 0.1]} />
            <meshStandardMaterial color="#9aa1ab" roughness={0.3} metalness={0.7} />
          </mesh>
          <mesh position={[sx * (E.door / 2 + side / 2 - shut * 1.6), WH / 2, 0.13]}>
            <boxGeometry args={[side + 0.02, WH - 0.05, 0.03]} />
            <meshStandardMaterial color="#e2b23a" roughness={0.25} metalness={0.5} />
          </mesh>
        </group>
      ))}
      {/* 床のドアの線 */}
      <mesh position={[0, 0.008, 0.02]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[E.door, 0.05]} />
        <meshBasicMaterial color="#ffd23a" />
      </mesh>
    </group>
  );
};

// 巨人の場面の町並み（2階建ての家・木・道路）。大きさの目安
const GiantTown: React.FC = () => {
  const houses = useMemo(
    () =>
      Array.from({ length: 13 }, (_, i) => ({
        x: -40 + i * 7.6,
        z: -16 - (i % 3) * 1.5,
        w: 5.5 + (i % 2) * 1.2,
        h: 5.6 + ((i * 37) % 5) * 0.4,
        wall: ["#f2e6d0", "#e9eef2", "#f4dccb", "#e2e8d8"][i % 4],
        roof: ["#8a3b2e", "#3d4f6b", "#5a4a3a", "#7a2f2f"][i % 4],
      })),
    [],
  );
  return (
    <group>
      {/* 道路 */}
      <mesh position={[0, 0.01, -7.5]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[200, 6]} />
        <meshStandardMaterial color="#5b5f66" roughness={0.9} />
      </mesh>
      {Array.from({ length: 30 }, (_, i) => (
        <mesh key={i} position={[-60 + i * 4.5, 0.02, -7.5]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[2.2, 0.18]} />
          <meshBasicMaterial color="#f2f2f2" />
        </mesh>
      ))}
      {houses.map((hs, i) => (
        <group key={i} position={[hs.x, 0, hs.z]}>
          <mesh position={[0, hs.h / 2, 0]} castShadow receiveShadow>
            <boxGeometry args={[hs.w, hs.h, 6]} />
            <meshStandardMaterial color={hs.wall} roughness={0.85} />
          </mesh>
          <mesh position={[0, hs.h + 1.2, 0]} rotation={[0, Math.PI / 4, 0]} castShadow>
            <coneGeometry args={[hs.w * 0.78, 2.4, 4]} />
            <meshStandardMaterial color={hs.roof} roughness={0.7} />
          </mesh>
          {[-1, 1].map((sx) =>
            [1.6, hs.h - 1.6].map((wy) => (
              <mesh key={`${sx}${wy}`} position={[sx * hs.w * 0.25, wy, 3.01]}>
                <planeGeometry args={[1.1, 1.0]} />
                <meshStandardMaterial color="#9cc4e4" roughness={0.2} />
              </mesh>
            )),
          )}
        </group>
      ))}
      {Array.from({ length: 9 }, (_, i) => (
        <group key={`t${i}`} position={[-36 + i * 10.5, 0, -11]}>
          <mesh position={[0, 1.4, 0]} castShadow>
            <cylinderGeometry args={[0.22, 0.3, 2.8, 10]} />
            <meshStandardMaterial color="#6b4a2e" />
          </mesh>
          <mesh position={[0, 3.8, 0]} castShadow>
            <sphereGeometry args={[1.7, 16, 12]} />
            <meshStandardMaterial color="#4f8f3a" roughness={0.9} />
          </mesh>
        </group>
      ))}
    </group>
  );
};

// 巨人が地面にぶつかったときの土けむりと、地面を走る衝撃の輪
const GiantDust: React.FC<{ sim: SimResult; f: number }> = ({ sim, f }) => {
  const hitT = giantHit(sim);
  if (hitT < 0) {
    return null;
  }
  const dt = f / sim.fps - hitT;
  if (dt < 0 || dt > 3.5) {
    return null;
  }
  // 土けむりの中心：ぶつかった瞬間の胴体の位置（巨人の大きさに直す）
  const hitF = Math.min(sim.frames - 1, Math.round(hitT * sim.fps));
  const ti = sim.bodies.findIndex((b) => b.part === (sim.kind === "gstand" ? "pelvis" : "torso") && b.lane === 1);
  const tp = posAt(sim, hitF, ti);
  const cx = GIANT_X[sim.kind][1] + tp[0] * GIANT;
  const cz = tp[2] * GIANT;
  const puffs = Array.from({ length: 46 }, (_, i) => {
    const a = random(`da${i}`) * Math.PI * 2;
    const sp = 2 + random(`ds${i}`) * 5;
    const d = sp * (1 - Math.exp(-dt * 1.6)) / 1.6;
    const r = 0.6 + dt * (0.8 + random(`dr${i}`) * 0.9);
    const along = (random(`dl${i}`) - 0.5) * (sim.kind === "gstand" ? 4 : 14);
    return (
      <mesh key={i} position={[cx + along + Math.cos(a) * d, 0.4 + r * 0.5 + dt * (0.4 + random(`dy${i}`)), cz + Math.sin(a) * d]}>
        <sphereGeometry args={[r, 10, 8]} />
        <meshStandardMaterial color="#cbb89a" transparent opacity={Math.max(0, 0.42 * (1 - dt / 3.5))} depthWrite={false} roughness={1} />
      </mesh>
    );
  });
  const ring = Math.min(1, dt / 0.9);
  return (
    <group>
      {puffs}
      {dt < 0.9 ? (
        <mesh position={[cx, 0.05, cz]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[2 + ring * 22, 2.8 + ring * 23, 64]} />
          <meshBasicMaterial color="#ffffff" transparent opacity={0.6 * (1 - ring)} depthWrite={false} />
        </mesh>
      ) : null}
    </group>
  );
};

const Cone: React.FC = () => (
  <group>
    <mesh castShadow>
      <cylinderGeometry args={[0.05, 0.2, 0.6, 24]} />
      <meshStandardMaterial color="#ff6a00" roughness={0.5} />
    </mesh>
    <mesh position={[0, 0.03, 0]}>
      <cylinderGeometry args={[0.112, 0.142, 0.12, 24]} />
      <meshStandardMaterial color="#f4f4f4" roughness={0.5} />
    </mesh>
    <mesh position={[0, -0.29, 0]} castShadow>
      <boxGeometry args={[0.44, 0.03, 0.44]} />
      <meshStandardMaterial color="#222" roughness={0.8} />
    </mesh>
  </group>
);

const shirtColor = (sim: SimResult, doll: number, lane: number) =>
  sim.kind === "party" || sim.kind === "fchaos" || sim.kind === "gold" || sim.kind === "goldgone" || sim.kind === "epack" ? PARTY_SHIRTS[doll % PARTY_SHIRTS.length] : LANE_COLORS[lane];

const Pill: React.FC<{
  x: number;
  y: number;
  color: string;
  children: React.ReactNode;
  size?: number;
  opacity?: number;
}> = ({ x, y, color, children, size = 46, opacity = 1 }) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      transform: "translate(-50%, -50%)",
      fontFamily,
      fontWeight: 900,
      fontSize: size,
      color: "#fff",
      background: color,
      padding: "4px 22px",
      borderRadius: 999,
      border: "5px solid #fff",
      boxShadow: "0 6px 14px rgba(0,0,0,0.35)",
      whiteSpace: "nowrap",
      opacity,
    }}
  >
    {children}
  </div>
);

// 水と同じ重さの空気の世界（右・奥）を、うすい青いもやと、ただよう小さな粒で見せる（粒は風といっしょに流れる）
const HeavyAirHaze: React.FC<{ sim: SimResult; f: number }> = ({ sim, f }) => {
  const t = f / sim.fps;
  // 風で流れた距離（風速を足し合わせる）
  let drift = 0;
  const w = sim.values.wind0;
  if (w) {
    for (let k = 0; k < f; k++) drift += w[k] / sim.fps;
  }
  // 範囲：[x0, x1], [y0, y1], [z0, z1]
  const box: [number, number, number, number, number, number] =
    sim.kind === "hjump" ? [0.75, 3.25, 0, 5.2, -1.4, 2.4] : sim.kind === "hthrow" ? [0.1, 6, 0, 3.4, -1.6, -0.3] : [-6, 10, 0, 2.6, -2.4, -0.6];
  const [x0, x1, y0, y1, z0, z1] = box;
  const n = sim.kind === "hjump" ? 110 : 150;
  const specks = Array.from({ length: n }, (_, i) => {
    const sx = random(`hx${i}`);
    const x = x0 + ((((sx * (x1 - x0) + drift + 0.04 * Math.sin(t * 0.9 + i)) % (x1 - x0)) + (x1 - x0)) % (x1 - x0));
    const y = y0 + random(`hy${i}`) * (y1 - y0) + 0.05 * Math.sin(t * 0.7 + i * 1.3);
    const z = z0 + random(`hz${i}`) * (z1 - z0);
    return (
      <mesh key={i} position={[x, y, z]}>
        <sphereGeometry args={[0.018, 6, 4]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0.55} />
      </mesh>
    );
  });
  return (
    <group>
      <mesh position={[(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2]}>
        <boxGeometry args={[x1 - x0, y1 - y0, z1 - z0]} />
        <meshBasicMaterial color="#5aa8ff" transparent opacity={0.1} depthWrite={false} />
      </mesh>
      {specks}
    </group>
  );
};

export const PhysicsScene: React.FC<{
  kind: SimKind;
  width: number;
  height: number;
  // 重力くらべの右（奥）の世界の重力（1G に対する倍率）
  gravity?: number;
  // 左右の世界の名前（省略するとシミュレーションの種類から決まる）
  labels?: [string, string];
  // シミュレーションの途中（フレーム）から見せる
  offset?: number;
  // ラベルや効果音を出さない（サムネイル用）
  bare?: boolean;
  // カメラの位置を指定する（サムネイル用）
  camera?: Cam;
}> = ({ kind, width, height, gravity = 0.5, labels, offset = 0, bare = false, camera }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const sim = useMemo(
    // 満員エレベーターは計算が重いので、どの場面でも同じ長さ（32秒）を計算して使い回す
    () => simulate(kind, kind === "epack" ? Math.max(fps * 32, durationInFrames + offset) : durationInFrames + offset, fps, gravity),
    [kind, durationInFrames, fps, gravity, offset],
  );
  const laneNames = labels ?? sim.labels;
  const f = Math.min(frame + offset, sim.frames - 1);
  // 横長の画面では、人がもう少し大きく見えるよう、カメラを少し近づける
  const landscape = width > height;
  const cam0 = camera ?? cameraFor(sim, f, sim.frames);
  const near = landscape && !["throw", "brake", "fbrake", "athrow", "aplane", "tjump", "tfall", "asky", "tworld"].includes(kind) ? 0.8 : 1;
  const cam: Cam = {
    pos: cam0.pos.map((p, i) => cam0.look[i] + (p - cam0.look[i]) * near) as [number, number, number],
    look: cam0.look,
  };
  // 横長では右上に章の名前が出るので、ラベル類を少し下げる
  const T = landscape ? 70 : 0;
  const ground = useGroundTexture(kind);
  const heightRuler = useRulerTexture(
    ["0m", "", "1m", "", "2m", "", "3m"],
    true,
  );
  const distRuler = useRulerTexture(
    Array.from({ length: 21 }, (_, i) => (i % 2 === 0 ? `${i}m` : "")),
    false,
  );
  const v = (name: string) => sim.values[name]?.[f] ?? 0;

  const overlays: React.ReactNode[] = [];
  const laneX = [width * 0.25, width * 0.75];
  const isRoad = sim.kind === "brake" || sim.kind === "fbrake" || sim.kind === "xbrake";
  const lanesTop = ["jump", "scale", "slip", "fstand", "wind", "afeather", "arain", "asky", "tlift", "tjump", "tfall", "twind", "train", "bjump", "bdrop", "bwall", "ice", "trconst", "tracc", "trbrake", "strfeet", "strhold", "lknee", "lmat", "tbutter", "tflick", "hjump"].includes(sim.kind);
  const isAir = AIR_KINDS.includes(sim.kind);
  // 摩擦ゼロの世界は、摩擦が消えた瞬間からラベルを点滅させる
  const offFrame = Math.round(FRICTION_OFF * fps);
  const isFriction = FRICTION_KINDS.includes(sim.kind);
  const blink =
    isFriction && f >= offFrame && f < offFrame + 24
      ? 1 + 0.18 * Math.sin(((f - offFrame) / 24) * Math.PI * 4)
      : 1;
  if (lanesTop) {
    const xs =
      sim.kind === "slip"
        ? [-0.8, 2.6]
        : sim.kind === "wind"
          ? [-1.5, 1.0]
          : sim.kind === "bdrop"
            ? [-0.9, 0.9]
            : sim.kind === "ice"
              ? [-1.0, 1.0]
              : TRAIN_KINDS.includes(sim.kind) || STRAP_KINDS.includes(sim.kind) || LAND_KINDS.includes(sim.kind)
                ? [-1.4, 1.4]
                : sim.kind === "hjump"
                  ? [-2.0, 2.0]
              : TOAST_KINDS.includes(sim.kind)
                ? TOAST.x
            : sim.kind === "bjump" || sim.kind === "bwall"
              ? [-1.4, 1.4]
            : sim.kind === "asky" || sim.kind === "tfall"
            ? [-1.35, 1.35]
            : sim.kind === "tlift"
              ? [-1.4, 1.4]
              : sim.kind === "tjump"
                ? [-3.0, 3.0]
                : sim.kind === "twind"
                  ? [-1.5, 1.0]
                  : sim.kind === "train"
                    ? [-1.3, 1.3]
          : sim.kind === "scale" || sim.kind === "jump"
            ? [-1, 1]
            : [-1.2, 1.2];
    xs.forEach((x, lane) => {
      const p = project(cam, [x, 0, 0], width, height);
      laneX[lane] = Math.min(width - 190, Math.max(190, p.x));
      overlays.push(
        <Pill key={`lane${lane}`} x={laneX[lane]} y={70 + T} color={LANE_COLORS[lane]} size={44 * (lane === 1 ? blink : 1)}>
          {laneNames[lane]}
        </Pill>,
      );
    });
  } else if (sim.kind === "throw" || sim.kind === "athrow" || sim.kind === "aplane" || sim.kind === "hthrow" || sim.kind === "hwind" || sim.kind === "hcar" || isRoad || sim.kind === "fpush" || sim.kind === "xpush" || sim.kind === "xslide" || sim.kind === "ladder" || SLOPE_KINDS.includes(sim.kind)) {
    overlays.push(
      <div key="legend" style={{ position: "absolute", left: 30, top: 34 + T, display: "flex", flexDirection: "column", gap: 12 }}>
        {[0, 1].map((lane) => (
          <div key={lane} style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 34, height: 34, borderRadius: 8, background: LANE_COLORS[lane], border: "4px solid #fff" }} />
            <div style={{ fontFamily, fontWeight: 900, fontSize: 40, color: "#fff", WebkitTextStroke: "8px #111", paintOrder: "stroke fill" }}>
              {laneNames[lane]}
            </div>
          </div>
        ))}
      </div>,
    );
  }

  if (sim.kind === "wind") {
    const w = v("wind0");
    overlays.push(
      <Pill key="wind" x={width / 2} y={150 + T} color="#334" size={40}>
        {`風速 ${Math.round(w)}m/s`}
      </Pill>,
    );
  }
  if (sim.kind === "hwind" || sim.kind === "hcar") {
    overlays.push(
      <Pill key="wind" x={width / 2} y={190 + T} color="#334" size={40}>
        {`弱い風 秒速${v("wind0").toFixed(1)}m`}
      </Pill>,
    );
  }
  if (sim.kind === "hjump") {
    // 跳び出してから着地するまでの時間
    [0, 1].forEach((lane) => {
      const time = v(`time${lane}`);
      const done = v(`landed${lane}`) > 0;
      overlays.push(
        <div
          key={`htime${lane}`}
          style={{
            position: "absolute",
            left: laneX[lane],
            top: 128 + T,
            transform: "translate(-50%, 0)",
            fontFamily,
            fontWeight: 900,
            fontSize: 64,
            color: done ? "#ffe14a" : "#fff",
            background: "rgba(10,16,28,0.78)",
            padding: "2px 26px",
            borderRadius: 14,
            border: `6px solid ${LANE_COLORS[lane]}`,
            whiteSpace: "nowrap",
          }}
        >
          {time.toFixed(1)}
          <span style={{ fontSize: 36 }}>{done ? "秒で着地" : "秒"}</span>
        </div>,
      );
    });
  }
  if (sim.kind === "scale") {
    [0, 1].forEach((lane) => {
      overlays.push(
        <div
          key={`kg${lane}`}
          style={{
            position: "absolute",
            left: laneX[lane],
            top: 128 + T,
            transform: "translate(-50%, 0)",
            fontFamily: "'Courier New', monospace",
            fontWeight: 900,
            fontSize: 74,
            color: "#7dff9a",
            background: "#0d1a12",
            padding: "4px 24px",
            borderRadius: 14,
            border: `6px solid ${LANE_COLORS[lane]}`,
            textShadow: "0 0 14px rgba(125,255,154,0.8)",
            whiteSpace: "nowrap",
          }}
        >
          {v(`kg${lane}`).toFixed(1)}
          <span style={{ fontSize: 40 }}> kg</span>
        </div>,
      );
    });
  }
  if (sim.kind === "jump") {
    [-1, 1].forEach((x, lane) => {
      const top = v(`top${lane}`);
      if (top > 0.15) {
        const p = project(cam, [x + 0.45, top, 0], width, height);
        overlays.push(
          <Pill key={`top${lane}`} x={p.x + 70} y={p.y} color={LANE_COLORS[lane]} size={40}>
            {`${top.toFixed(1)}m`}
          </Pill>,
        );
      }
    });
  }
  if (sim.kind === "slip") {
    [0, 1].forEach((lane) => {
      overlays.push(
        <div
          key={`timer${lane}`}
          style={{
            position: "absolute",
            left: laneX[lane],
            top: 128 + T,
            transform: "translate(-50%, 0)",
            fontFamily,
            fontWeight: 900,
            fontSize: 60,
            color: "#111",
            background: "#fff",
            padding: "2px 22px",
            borderRadius: 16,
            border: `6px solid ${LANE_COLORS[lane]}`,
            whiteSpace: "nowrap",
          }}
        >
          {`⏱ ${v(`timer${lane}`).toFixed(2)}秒`}
        </div>,
      );
    });
  }
  if (sim.kind === "throw" || sim.kind === "athrow" || sim.kind === "aplane") {
    [0, 1].forEach((lane) => {
      const land = v(`land${lane}`);
      if (land > 0) {
        const p = project(cam, [land, 0.9, lane === 0 ? 0.9 : -0.9], width, height);
        overlays.push(
          <Pill key={`land${lane}`} x={Math.min(width - 120, Math.max(120, p.x))} y={Math.max(190 + T, p.y - 40)} color={LANE_COLORS[lane]} size={42}>
            {sim.kind === "throw" ? `約${Math.round(land)}m` : `${land.toFixed(1)}m`}
          </Pill>,
        );
      }
    });
  }
  if (sim.kind === "afeather") {
    // ストップウォッチ：手をはなしてから地面に着くまで
    [0, 1].forEach((lane) => {
      const ball = v(`ball${lane}`);
      const feather = v(`feather${lane}`);
      const row = (name: string, t: number, done: boolean) => (
        <div style={{ display: "flex", justifyContent: "space-between", gap: 18 }}>
          <span style={{ fontSize: 28 }}>{name}</span>
          <span style={{ color: done ? "#111" : "#888" }}>{`${Math.abs(t).toFixed(2)}秒`}</span>
        </div>
      );
      overlays.push(
        <div
          key={`sw${lane}`}
          style={{
            position: "absolute",
            left: laneX[lane],
            top: 118 + T,
            transform: "translate(-50%, 0)",
            fontFamily,
            fontWeight: 900,
            fontSize: 36,
            color: "#111",
            background: "#fff",
            padding: "4px 22px",
            borderRadius: 16,
            border: `6px solid ${LANE_COLORS[lane]}`,
            whiteSpace: "nowrap",
            minWidth: 250,
          }}
        >
          {row("鉄球", ball, ball > 0 && f > 0 && v(`ball${lane}`) === sim.values[`ball${lane}`][Math.max(0, f - 1)])}
          {row("羽根", feather, feather > 0)}
        </div>,
      );
      if (lane === 1 && feather > 0 && ball > 0) {
        overlays.push(
          <Pill key="same" x={width / 2} y={150 + T} color="#ff8a00" size={44}>
            同時に着地！
          </Pill>,
        );
      }
    });
  }
  if (sim.kind === "arain") {
    overlays.push(
      <Pill key="r0" x={laneX[0]} y={150 + T} color="#334" size={38}>雨粒 時速30km</Pill>,
      <Pill key="r1" x={laneX[1]} y={150 + T} color="#c0182b" size={38}>雨粒 時速500km</Pill>,
    );
  }
  if (sim.kind === "asky") {
    [0, 1].forEach((lane) => {
      const kmh = v(`v${lane}`);
      const h = v(`h${lane}`);
      overlays.push(
        <div
          key={`hud${lane}`}
          style={{
            position: "absolute",
            left: laneX[lane],
            top: 124 + T,
            transform: "translate(-50%, 0)",
            display: "flex",
            flexDirection: "column",
            gap: 8,
            alignItems: "stretch",
          }}
        >
          {[
            ["時速", `${Math.round(kmh).toLocaleString()} km`, lane === 1 && kmh > 600 ? "#ff5a5a" : "#7dff9a"],
            ["高度", `${Math.round(h).toLocaleString()} m`, h < 500 ? "#ff5a5a" : "#7dff9a"],
          ].map(([k, val, c]) => (
            <div key={k} style={{ fontFamily, fontWeight: 900, fontSize: 44, color: c, background: "rgba(0,0,0,0.7)", border: `4px solid ${LANE_COLORS[lane]}`, borderRadius: 14, padding: "0 16px", whiteSpace: "nowrap", textAlign: "right" }}>
              <span style={{ color: "#fff", fontSize: 30, marginRight: 12 }}>{k}</span>
              {val}
            </div>
          ))}
        </div>,
      );
    });
    overlays.push(
      <Pill key="t" x={width / 2} y={330 + T} color="#222" size={36}>
        {`飛び降りて ${Math.floor(v("t0"))}秒`}
      </Pill>,
    );
    if (v("h1") < 400) {
      overlays.push(
        <Pill key="warn" x={laneX[1]} y={420 + T} color="#e01b2f" size={44 * (1 + 0.06 * Math.sin(f * 0.8))}>
          地面が目の前！
        </Pill>,
      );
    }
  }
  if (isRoad) {
    [0, 1].forEach((lane) => {
      const stop = v(`stop${lane}`);
      const carX = posAt(sim, f, findIndex(sim, "car", lane))[0];
      if (stop < 0 && sim.kind === "fbrake" && carX > 9) {
        // 摩擦がないので、ブレーキをかけても止まれない
        overlays.push(
          <Pill key={`stop${lane}`} x={width * 0.62} y={190 + T} color={LANE_COLORS[lane]} size={46}>
            止まれない！
          </Pill>,
        );
      }
      if (stop > 0) {
        const p = project(cam, [stop - 2, 1.8, lane === 0 ? 1.7 : -1.7], width, height);
        overlays.push(
          <Pill key={`stop${lane}`} x={Math.min(width - 200, Math.max(200, p.x))} y={Math.max(240 + T, p.y - 30)} color={LANE_COLORS[lane]} size={42}>
            {`${stop.toFixed(1)}mで停止`}
          </Pill>,
        );
      }
    });
  }

  if (sim.kind === "elevfall" || sim.kind === "elevsafe" || sim.kind === "elevfloat") {
    const fall = v("fall");
    const floor = Math.max(1, Math.round(ELEV.height / ELEV.floor - fall / ELEV.floor));
    if (sim.kind === "elevfloat") {
      overlays.push(
        <Pill key="slow" x={width / 2} y={height * 0.5} color="#7a3cff" size={34}>
          スロー（1/4）
        </Pill>,
      );
    }
    overlays.push(
      <div
        key="ind"
        style={{
          position: "absolute",
          left: 40,
          top: 40 + T,
          fontFamily: "'Courier New', monospace",
          fontWeight: 900,
          fontSize: 70,
          color: "#ffb020",
          background: "#111",
          border: "5px solid #444",
          borderRadius: 14,
          padding: "0 22px",
          textShadow: "0 0 14px rgba(255,176,32,0.8)",
        }}
      >
        {`${floor}F`}
      </div>,
      <div
        key="spd"
        style={{
          position: "absolute",
          right: 40,
          top: 50 + T,
          fontFamily,
          fontWeight: 900,
          fontSize: 50,
          color: v("speed") > 60 ? "#ff5a5a" : "#7dff9a",
          background: "rgba(0,0,0,0.7)",
          borderRadius: 14,
          padding: "0 18px",
        }}
      >
        <span style={{ fontSize: 30, color: "#fff", marginRight: 10 }}>時速</span>
        {`${Math.round(v("speed"))} km`}
      </div>,
    );
    const snapF = Math.round((ELEV.snap / (sim.kind === "elevfloat" ? ELEV.slow : 1)) * fps);
    if (f >= snapF && f < snapF + 30) {
      overlays.push(
        <Pill key="snap" x={width / 2} y={190 + T} color="#e01b2f" size={48 * (1 + 0.08 * Math.sin(f))}>
          ロープが切れた！
        </Pill>,
      );
    }
    const hitT = v("hit");
    if (hitT >= 0) {
      overlays.push(<AbsoluteFill key="flash" style={{ background: "#fff", opacity: Math.max(0, 1 - hitT / 0.5) }} />);
    }
  }
  if (sim.kind === "rwalk" || sim.kind === "rrun") {
    const hits = v("hits");
    const d = v("dist");
    const arrived = d >= RAIN.dist - 0.01;
    overlays.push(
      <Pill key="mode" x={width / 2} y={70 + T} color={sim.kind === "rrun" ? "#2f8bff" : "#ff4a3d"} size={40}>
        {labels?.[0] || (sim.kind === "rrun" ? "走る（秒速5m）" : "歩く（秒速1.5m）")}
      </Pill>,
      <div
        key="cnt"
        style={{
          position: "absolute",
          left: width / 2,
          top: 120 + T,
          transform: "translate(-50%, 0)",
          fontFamily,
          fontWeight: 900,
          fontSize: 60,
          color: "#9fd3ff",
          background: "rgba(0,0,0,0.7)",
          border: "5px solid #9fd3ff",
          borderRadius: 18,
          padding: "2px 26px",
          whiteSpace: "nowrap",
        }}
      >
        <span style={{ fontSize: 34, color: "#fff", marginRight: 14 }}>ぬれた雨粒</span>
        {Math.round(hits).toLocaleString()}
        <span style={{ fontSize: 34 }}> 粒</span>
      </div>,
      <Pill key="dist" x={width / 2} y={250 + T} color={arrived ? "#1f8f4e" : "#334"} size={34}>
        {arrived ? "コンビニに到着！" : `コンビニまで ${(RAIN.dist - d).toFixed(1)}m`}
      </Pill>,
    );
  }
  if (BLANKET_KINDS.includes(sim.kind)) {
    const bk = BLANKETS[sim.kind];
    // 寝ている人の頭の上に「Zzz」（ゆっくり上へ浮かぶ）
    const hi = sim.bodies.findIndex((b) => b.part === "head");
    const hp = posAt(sim, f, hi);
    ["Z", "z", "z"].forEach((ch, i) => {
      const ph = ((f / fps) * 0.6 + i / 3) % 1;
      const p = project(cam, [hp[0] + 0.12 + ph * 0.25, hp[1] + 0.2 + ph * 0.45, hp[2]], width, height);
      overlays.push(
        <div
          key={`z${i}`}
          style={{
            position: "absolute",
            left: p.x,
            top: p.y,
            transform: "translate(-50%, -50%)",
            fontFamily,
            fontWeight: 900,
            fontSize: 44 + ph * 26,
            color: "#5b6fd6",
            opacity: Math.sin(ph * Math.PI),
            WebkitTextStroke: "6px #fff",
            paintOrder: "stroke fill",
          }}
        >
          {ch}
        </div>,
      );
    });
    overlays.push(
      <div
        key="bk"
        style={{
          position: "absolute",
          left: 28,
          top: 40 + T,
          fontFamily,
          fontWeight: 900,
          color: "#fff",
          textAlign: "center",
          background: "rgba(40,30,22,0.78)",
          border: "5px solid #fff",
          borderRadius: 26,
          padding: "8px 30px",
          whiteSpace: "nowrap",
        }}
      >
        <div style={{ fontSize: 58, lineHeight: 1.1 }}>{bk.name}</div>
        <div style={{ fontSize: 34, color: "#ffd98a" }}>{bk.kg}</div>
      </div>,
    );
  }
  if (sim.kind === "epack") {
    const n = v("count");
    const kg = n * 66;
    const full = v("full");
    const over = kg > ELEVPACK.limit;
    overlays.push(
      <div
        key="cnt"
        style={{
          position: "absolute",
          right: 24,
          top: 120 + T,
          width: 300,
          fontFamily,
          fontWeight: 900,
          color: "#fff",
          background: "rgba(20,24,32,0.85)",
          border: `5px solid ${over ? "#e01b2f" : "#ffd23a"}`,
          borderRadius: 22,
          padding: "10px 16px",
          textAlign: "center",
        }}
      >
        <div style={{ fontSize: 24, color: "#cfd6df" }}>定員11名・750kg</div>
        <div style={{ fontSize: 30 }}>乗った人</div>
        <div style={{ fontSize: 92, lineHeight: 1, color: over ? "#ff6b6b" : "#ffd23a" }}>
          {n}
          <span style={{ fontSize: 40 }}>人</span>
        </div>
        <div style={{ fontSize: 28, marginTop: 6 }}>{`重さ ${kg}kg / 750kg`}</div>
        <div style={{ height: 18, background: "#3a3f48", borderRadius: 9, marginTop: 6, overflow: "hidden" }}>
          <div style={{ width: `${Math.min(100, (kg / ELEVPACK.limit) * 100)}%`, height: "100%", background: over ? "#e01b2f" : "#2fc46b" }} />
        </div>
      </div>,
    );
    if (full > 0 && f / fps > full) {
      overlays.push(
        <div
          key="full"
          style={{
            position: "absolute",
            right: 24,
            top: 395 + T,
            width: 300,
            fontFamily,
            fontWeight: 900,
            fontSize: 34,
            lineHeight: 1.2,
            color: "#fff",
            background: "#e01b2f",
            border: "5px solid #fff",
            borderRadius: 22,
            padding: "8px 10px",
            textAlign: "center",
            boxShadow: "0 6px 14px rgba(0,0,0,0.35)",
          }}
        >
          {`${v("who")}人目は`}
          <br />
          ドアが
          <br />
          閉まらない！
        </div>,
      );
    }
  }
  if (GIANT_KINDS.includes(sim.kind) && sim.kind !== "gfallLow") {
    const gx = GIANT_X[sim.kind];
    const hi = (lane: number) => {
      const idx = sim.bodies.findIndex((b) => b.part === "head" && b.lane === lane);
      const p = posAt(sim, f, idx);
      return lane === 1 ? [gx[1] + p[0] * GIANT, p[1] * GIANT, p[2] * GIANT] : p;
    };
    [0, 1].forEach((lane) => {
      const h = hi(lane);
      const p = project(cam, [h[0], h[1] + (lane === 1 ? 2.2 : 0.7), h[2]], width, height);
      overlays.push(
        <Pill key={`gn${lane}`} x={Math.min(width - 200, Math.max(200, p.x))} y={Math.max(150 + T, p.y)} color={LANE_COLORS[lane]} size={lane === 1 ? 40 : 30}>
          {lane === 0 ? "ふつうの人 1.75m" : "巨人 17.5m"}
        </Pill>,
      );
    });
    if (sim.kind === "gstand") {
      const dn = v("down1");
      if (dn > 0 && f / fps > dn + 0.3) {
        const h = hi(1);
        const p = project(cam, [h[0], h[1] * 0.5, 0], width, height);
        overlays.push(
          <Pill key="gres" x={Math.min(width - 230, p.x)} y={p.y} color="#e01b2f" size={46}>
            立ち上がれない！
          </Pill>,
        );
      }
    } else {
      [0, 1].forEach((lane) => {
        const hit = v(`hit${lane}`);
        if (hit > 0) {
          overlays.push(
            <Pill key={`gh${lane}`} x={width / 2} y={175 + T + lane * 78} color={lane === 1 ? "#e01b2f" : "#334"} size={lane === 1 ? 44 : 34}>
              {`${lane === 1 ? "巨人" : "ふつうの人"}の頭が落ちてくる速さ 時速${Math.round(hit)}km`}
            </Pill>,
          );
        }
      });
    }
  }
  if (TOAST_KINDS.includes(sim.kind)) {
    [0, 1].forEach((lane) => {
      const face = sim.kind === "tbutter" && lane === 1 ? "印" : "バター";
      const dn = v(`down${lane}`);
      const upN = v(`up${lane}`);
      overlays.push(
        <div
          key={`tc${lane}`}
          style={{
            position: "absolute",
            left: laneX[lane],
            top: 150 + T,
            transform: "translate(-50%, 0)",
            fontFamily,
            fontWeight: 900,
            color: "#fff",
            textAlign: "center",
            background: "rgba(20,24,32,0.82)",
            border: `5px solid ${LANE_COLORS[lane]}`,
            borderRadius: 20,
            padding: "6px 18px",
            whiteSpace: "nowrap",
          }}
        >
          <div style={{ fontSize: 34, color: "#ffd166" }}>{`${face}が下 ${dn}枚`}</div>
          <div style={{ fontSize: 34, color: "#9be7ff" }}>{`${face}が上 ${upN}枚`}</div>
        </div>,
      );
    });
  }
  if (LAND_KINDS.includes(sim.kind)) {
    [-1.4, 1.4].forEach((x0, lane) => {
      // 台の高さ（台の前の面に）
      const p = project(cam, [x0, LAND.h * 0.55, LAND.z + 0.36], width, height);
      overlays.push(
        <Pill key={`h${lane}`} x={p.x} y={p.y} color="#334" size={30}>
          高さ1m
        </Pill>,
      );
      // 着地したら、衝撃（地面が体を押し返す力のいちばん大きい値）を、体重の何倍かで出す
      const touch = v(`landed${lane}`);
      if (touch > 0 && f / fps > touch + 0.12) {
        const peak = v(`peak${lane}`);
        const pop = Math.min(1, (f / fps - touch - 0.12) / 0.15);
        overlays.push(
          <div
            key={`pk${lane}`}
            style={{
              position: "absolute",
              left: laneX[lane],
              top: 172 + T,
              transform: `translate(-50%, -50%) scale(${0.6 + 0.4 * pop})`,
              textAlign: "center",
              fontFamily,
              fontWeight: 900,
              color: "#fff",
              background: peak > 10 ? "#e01b2f" : "#1f8f4e",
              padding: "10px 26px",
              borderRadius: 26,
              border: "6px solid #fff",
              boxShadow: "0 8px 18px rgba(0,0,0,0.35)",
              whiteSpace: "nowrap",
            }}
          >
            <div style={{ fontSize: 30 }}>着地の衝撃</div>
            <div style={{ fontSize: 66, lineHeight: 1.05 }}>
              体重の{peak.toFixed(1)}倍
            </div>
          </div>,
        );
      }
    });
  }
  if (STRAP_KINDS.includes(sim.kind)) {
    const braking = f / fps > STRAP.t0;
    const kmh = v("v0");
    overlays.push(
      <Pill key="sp" x={width / 2} y={height * 0.36} color={braking ? "#e01b2f" : "#334"} size={36}>
        {braking ? (kmh < 0.5 ? "停車" : `急ブレーキ！ 時速${Math.round(kmh)}km`) : `時速${Math.round(kmh)}km →`}
      </Pill>,
    );
    [0, 1].forEach((lane) => {
      const fell = v(`fell${lane}`) > 0;
      const cm = Math.round(Math.abs(v(`moved${lane}`)) * 100);
      if (fell) {
        overlays.push(
          <Pill key={`r${lane}`} x={laneX[lane]} y={height * 0.5} color="#e01b2f" size={48}>倒れた！</Pill>,
        );
      } else if (f / fps > STRAP.t0 + 2.4) {
        overlays.push(
          <Pill key={`r${lane}`} x={laneX[lane]} y={height * 0.5} color="#1f8f4e" size={44}>{`ゆれ ${cm}cm`}</Pill>,
        );
      }
    });
  }
  if (TRAIN_KINDS.includes(sim.kind)) {
    [0, 1].forEach((lane) => {
      const kmh = v(`v${lane}`);
      overlays.push(
        <Pill key={`sp${lane}`} x={laneX[lane]} y={140 + T} color="#334" size={32}>
          {kmh < 0.5 ? "止まっている" : `時速${Math.round(kmh)}km →`}
        </Pill>,
      );
      const sh = sim.values[`shift${lane}`][f];
      if (!Number.isNaN(sh)) {
        const cm = Math.round(sh * 100);
        overlays.push(
          <Pill key={`sh${lane}`} x={laneX[lane]} y={height * 0.48} color={Math.abs(cm) < 4 ? "#1f8f4e" : "#e01b2f"} size={44}>
            {Math.abs(cm) < 4 ? "ズレ ほぼ0cm" : cm < 0 ? `後ろへ ${-cm}cm` : `前へ ${cm}cm`}
          </Pill>,
        );
      }
    });
  }
  if (sim.kind === "gold" || sim.kind === "goldgone") {
    const gone = v("gone");
    overlays.push(
      <Pill key="g1" x={width / 2} y={80 + T} color="#b8860b" size={40} opacity={1 - gone}>
        人類が掘り出した金 ぜんぶ
      </Pill>,
      <Pill key="g2" x={width / 2} y={150 + T} color="#222" size={36} opacity={1 - gone}>
        約21万トン・一辺 約22m
      </Pill>,
    );
    if (gone >= 1) {
      overlays.push(
        <Pill key="g3" x={width / 2} y={110 + T} color="#e01b2f" size={56}>
          消えた！
        </Pill>,
      );
    }
  }
  if (sim.kind === "ice") {
    overlays.push(
      <Pill key="d0" x={laneX[0]} y={140 + T} color="#334" size={30}>氷の重さ：水の0.92倍</Pill>,
      <Pill key="d1" x={laneX[1]} y={140 + T} color="#334" size={30}>水の1.08倍（もしも）</Pill>,
    );
    if (f > 3.6 * fps) {
      overlays.push(
        <Pill key="r0" x={laneX[0]} y={205 + T} color={LANE_COLORS[0]} size={42}>浮く！</Pill>,
        <Pill key="r1" x={laneX[1]} y={205 + T} color={LANE_COLORS[1]} size={42}>沈む…</Pill>,
      );
    }
  }
  if (sim.kind === "xslide") {
    [0, 1].forEach((lane) => {
      const moved = v(`slide${lane}`);
      if (f > 1.9 * fps) {
        const pi = sim.bodies.findIndex((b) => b.part === "head" && b.lane === lane);
        const hp = posAt(sim, f, pi);
        const p = project(cam, [hp[0], hp[1] + 0.45, hp[2]], width, height);
        overlays.push(
          <Pill key={`sl${lane}`} x={Math.min(width - 150, Math.max(150, p.x))} y={Math.max(200 + T, p.y)} color={LANE_COLORS[lane]} size={40}>
            {moved > 0.8 ? "すべる！" : "すべらない…"}
          </Pill>,
        );
      }
    });
    const p = project(cam, [1.6, 0.5, 1.6], width, height);
    overlays.push(
      <Pill key="ang" x={p.x} y={p.y} color="#334" size={32}>角度35°</Pill>,
    );
  }
  if (SLOPE_KINDS.includes(sim.kind)) {
    // それぞれの物の上に「どれだけ動いたか」。坂のそばに角度
    const pick = (lane: number) =>
      sim.kind === "slfall"
        ? sim.bodies.findIndex((b) => b.part === "head" && b.lane === lane)
        : sim.bodies.findIndex((b) => (sim.kind === "slball" ? b.shape === "sphere" : b.shape === "box" && b.size[0] < 0.5) && b.lane === lane);
    [0, 1].forEach((lane) => {
      const bi = pick(lane);
      if (bi < 0) return;
      const bp = posAt(sim, f, bi);
      const d = Math.max(0, v(`dist${lane}`));
      const p = project(cam, [bp[0], bp[1] + (sim.kind === "slfall" ? 0.5 : 0.45), bp[2]], width, height);
      const verb = sim.kind === "slball" ? "転がった" : sim.kind === "slbox" ? "すべった" : "すべり落ちた";
      const text = d < 0.3 || (sim.kind === "slfall" && lane === 0) ? (sim.kind === "slfall" ? "その場で止まる" : "止まったまま") : `${d.toFixed(1)}m ${verb}`;
      if (f > 0.4 * fps)
        overlays.push(
          <Pill key={`sl${lane}`} x={Math.min(width - 160, Math.max(160, p.x))} y={Math.max(190 + T, Math.min(height - 140, p.y))} color={LANE_COLORS[lane]} size={38}>
            {text}
          </Pill>,
        );
    });
    const ap = project(cam, [SLOPE.x0 + 2.6, 0.5, 0.9], width, height);
    overlays.push(
      <Pill key="ang" x={Math.min(width - 120, Math.max(120, ap.x))} y={Math.min(height - 120, ap.y)} color="#334" size={32}>坂 30°</Pill>,
    );
  }
  if (sim.kind === "fpush" || sim.kind === "xpush") {
    [0, 1].forEach((lane) => {
      const bi = findIndex(sim, "box", lane);
      const p = project(cam, [posAt(sim, f, bi)[0], 1.05, lane === 0 ? 0.9 : -0.9], width, height);
      const moved = Math.max(0, v(`box${lane}`));
      overlays.push(
        <Pill key={`box${lane}`} x={Math.min(width - 120, Math.max(120, p.x))} y={Math.max(190 + T, p.y - 20)} color={LANE_COLORS[lane]} size={40}>
          {moved < 0.05 ? "びくともしない" : `箱 ${moved.toFixed(1)}m →`}
        </Pill>,
      );
    });
  }

  if (sim.kind === "tunnel" || sim.kind === "tunnelzero") {
    // 速さは、中身が均一な地球を通る穴の計算（中心で時速 約2万8000km）を場面に合わせて表示
    const p = f / Math.max(1, sim.frames - 1);
    const kmh = sim.kind === "tunnelzero" ? 28000 : 28000 * Math.sin((Math.PI / 2) * 0.85 * p);
    overlays.push(
      <div key="hud" style={{ position: "absolute", left: 30, top: 30 + T, display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ fontFamily, fontWeight: 900, fontSize: 44, color: "#7dff9a", background: "rgba(0,0,0,0.65)", border: "3px solid rgba(125,255,154,0.6)", borderRadius: 14, padding: "2px 18px", whiteSpace: "nowrap" }}>
          <span style={{ color: "#fff", fontSize: 32, marginRight: 12 }}>時速</span>
          {`${Math.round(kmh).toLocaleString()} km`}
        </div>
      </div>,
    );
    if (sim.kind === "tunnelzero") {
      overlays.push(
        <Pill key="zero" x={width - 190} y={70 + T} color="#7a3cff" size={46}>
          重力ゼロ
        </Pill>,
      );
    }
  }

  if (sim.kind === "bjump") {
    [-1.4, 1.4].forEach((x, lane) => {
      const top = v(`top${lane}`);
      if (top > 0.15) {
        const p = project(cam, [x + 0.5, top, 0], width, height);
        overlays.push(
          <Pill key={`top${lane}`} x={Math.min(width - 120, p.x + 90)} y={Math.max(150 + T, p.y)} color={LANE_COLORS[lane]} size={40}>
            {`${top.toFixed(1)}m`}
          </Pill>,
        );
      }
    });
  }
  if (sim.kind === "bdrop") {
    if (v("broken0") > 0) {
      overlays.push(
        <Pill key="b0" x={laneX[0]} y={150 + T} color="#c0182b" size={42}>割れた！</Pill>,
      );
    }
    // トランポリンの卵：一度はね返ったら「割れない！」
    const ei = sim.bodies.findIndex((b) => b.shape === "egg" && b.lane === 1);
    let bounced = false;
    for (let k = 1; k <= f; k++) {
      if (posAt(sim, k, ei)[1] > posAt(sim, k - 1, ei)[1] + 0.005 && posAt(sim, k, ei)[1] < 0.6) {
        bounced = true;
        break;
      }
    }
    if (bounced) {
      overlays.push(
        <Pill key="b1" x={laneX[1]} y={150 + T} color="#1f8f4e" size={42}>割れない！</Pill>,
      );
    }
  }
  if (sim.kind === "bwall") {
    [-2.3, 0.5].forEach((x, lane) => {
      const p = project(cam, [x, 3.05, 0], width, height);
      overlays.push(
        <Pill key={`h${lane}`} x={p.x} y={p.y - 30} color="#334" size={30}>高さ3m</Pill>,
      );
    });
  }
  if (sim.kind === "tworld") {
    overlays.push(
      <Pill key="title" x={width / 2} y={70 + T} color="#7a3cff" size={40}>
        身長10cmの世界（17.5倍に拡大）
      </Pill>,
    );
    // まわりの物の名前（カメラの前にあるときだけ）
    for (const prop of TINY_PROPS) {
      const p = project(cam, prop.label, width, height);
      const d = Math.hypot(cam.pos[0] - prop.label[0], cam.pos[2] - prop.label[2]);
      const toLook = [cam.look[0] - cam.pos[0], cam.look[2] - cam.pos[2]];
      const toProp = [prop.label[0] - cam.pos[0], prop.label[2] - cam.pos[2]];
      const front = toLook[0] * toProp[0] + toLook[1] * toProp[1] > 0;
      if (front && d > 2.5 && p.x > 120 && p.x < width - 120 && p.y > 130 + T) {
        overlays.push(
          <Pill key={prop.name} x={p.x} y={p.y} color="#222" size={34}>
            {prop.name}
          </Pill>,
        );
      }
    }
  }
  if (sim.kind === "tlift") {
    const late = f > 2.6 * fps;
    overlays.push(
      <Pill key="w0" x={laneX[0]} y={145 + T} color="#334" size={32}>バーベル132kg（体重の2倍）</Pill>,
      <Pill key="w1" x={laneX[1]} y={145 + T} color="#334" size={32}>500円玉4枚 28g（体重の2倍）</Pill>,
    );
    if (late) {
      overlays.push(
        <Pill key="r0" x={laneX[0]} y={215 + T} color={LANE_COLORS[0]} size={40}>持ち上がらない…</Pill>,
        <Pill key="r1" x={laneX[1]} y={215 + T} color={LANE_COLORS[1]} size={40}>軽々！</Pill>,
      );
    }
  }
  if (sim.kind === "tjump") {
    [-3.0, 3.0].forEach((x, lane) => {
      const top = v(`top${lane}`);
      if (top > 0.1) {
        const p = project(cam, [x + 0.5, top, 0], width, height);
        const real = lane === 0 ? top : top / TINY;
        overlays.push(
          <Pill key={`top${lane}`} x={Math.min(width - 260, p.x + 150)} y={Math.max(150 + T, p.y)} color={LANE_COLORS[lane]} size={36}>
            {lane === 0 ? `${Math.round(real * 100)}cm` : `${Math.round(real * 100)}cm（身長の${(real / 0.1).toFixed(1)}倍）`}
          </Pill>,
        );
      }
    });
  }
  if (sim.kind === "tfall") {
    [0, 1].forEach((lane) => {
      const kmh = v(`v${lane}`);
      const h = v(`h${lane}`);
      overlays.push(
        <div
          key={`hud${lane}`}
          style={{ position: "absolute", left: laneX[lane], top: 124 + T, transform: "translate(-50%, 0)", display: "flex", flexDirection: "column", gap: 8 }}
        >
          {[
            ["時速", `${Math.round(kmh)} km`],
            ["高さ", `${h.toFixed(1)} m`],
          ].map(([k, val]) => (
            <div key={k} style={{ fontFamily, fontWeight: 900, fontSize: 42, color: "#7dff9a", background: "rgba(0,0,0,0.7)", border: `4px solid ${LANE_COLORS[lane]}`, borderRadius: 14, padding: "0 16px", whiteSpace: "nowrap", textAlign: "right" }}>
              <span style={{ color: "#fff", fontSize: 28, marginRight: 12 }}>{k}</span>
              {val}
            </div>
          ))}
        </div>,
      );
      if (h <= 0) {
        overlays.push(
          <Pill key={`land${lane}`} x={laneX[lane]} y={300 + T} color={LANE_COLORS[lane]} size={38}>
            {`地面に着く速さ 時速${Math.round(kmh)}km`}
          </Pill>,
        );
      }
    });
  }
  if (sim.kind === "twind") {
    overlays.push(
      <Pill key="wind" x={width / 2} y={150 + T} color="#334" size={38}>
        {`どちらも 風速${v("wind0").toFixed(0)}m/s`}
      </Pill>,
    );
    if (v("wind0") > 5) {
      overlays.push(
        <Pill key="ty" x={laneX[1]} y={225 + T} color="#e01b2f" size={40}>
          台風なみ！
        </Pill>,
      );
    }
  }
  if (sim.kind === "train") {
    if (v("hit1") > 0) {
      overlays.push(
        <Pill key="h0" x={laneX[0]} y={150 + T} color="#334" size={36}>何も感じない</Pill>,
        <Pill key="h1" x={laneX[1]} y={150 + T} color="#e01b2f" size={36}>雨粒1つで よろける！</Pill>,
      );
    }
  }

  // ボールの軌跡（0.5秒前までの位置を点で）
  const trails: React.ReactNode[] = [];
  if (sim.kind === "throw" || sim.kind === "athrow" || sim.kind === "aplane") {
    [0, 1].forEach((lane) => {
      const bi = findIndex(sim, sim.kind === "aplane" ? "plane" : "sphere", lane);
      for (let k = 2; k <= f; k += 2) {
        const p = posAt(sim, k, bi);
        if (p[0] < 0.5) {
          continue;
        }
        trails.push(
          <mesh key={`tr${lane}-${k}`} position={p}>
            <sphereGeometry args={[0.07, 10, 10]} />
            <meshBasicMaterial color={LANE_COLORS[lane]} transparent opacity={0.55} />
          </mesh>,
        );
      }
    });
  }

  // 効果音：ぶつかった速さで音量を変える（音の大きさは速さの約1.5乗で増える）。
  // 人の音は高さ違いの3種類を順番に使い、毎回まったく同じ音にならないようにする
  const sounds = sim.impacts
    .filter((hit) => hit.frame >= offset && kind !== "epack")
    .map((hit, i) => {
    const spec = HIT_SOUNDS[hit.sound];
    const file =
      hit.sound === "body" ? `sfx/thud${(i % 3) + 1}.wav` : spec.file;
    const volume = spec.max * Math.min(1, (hit.v / spec.ref) ** 1.5);
    return (
      <Sequence key={i} from={hit.frame - offset} durationInFrames={15}>
        <Audio src={staticFile(file)} volume={volume} />
      </Sequence>
    );
  });

  // 満員エレベーター：1人乗るたびに小さな音、満員になったらドアが人に当たる音
  if (kind === "epack") {
    const c = sim.values["count"];
    for (let k = Math.max(1, offset); k < Math.min(sim.frames, offset + durationInFrames); k++) {
      if (c[k] > c[k - 1]) {
        sounds.push(
          <Sequence key={`in${k}`} from={k - offset} durationInFrames={12}>
            <Audio src={staticFile("sfx/pop.wav")} volume={0.16} />
          </Sequence>,
        );
      }
    }
    const fullT = sim.values["full"][sim.frames - 1];
    if (fullT > 0) {
      for (let j = 0; j < 3; j++) {
        // ドアがしまりかけて当たる（sin の山のところ）
        const hf = Math.round((fullT + (Math.PI / 2.2) * (j + 0.5)) * fps) - offset;
        if (hf >= 0 && hf < durationInFrames) {
          sounds.push(
            <Sequence key={`door${j}`} from={hf} durationInFrames={12}>
              <Audio src={staticFile("sfx/clack.wav")} volume={0.2} />
            </Sequence>,
          );
        }
      }
    }
  }

  // 巨人が地面にぶつかった音（重く低い音。大きさはぶつかる速さに合わせて控えめに）
  if (GIANT_KINDS.includes(kind)) {
    const hitT = giantHit(sim);
    const hf = Math.round(hitT * fps) - offset;
    if (hitT > 0 && hf >= 0) {
      const speed = sim.values["hit1"][sim.frames - 1];
      sounds.push(
        <Sequence key="boom" from={hf} durationInFrames={40}>
          <Audio src={staticFile("sfx/impact.wav")} volume={Math.min(0.5, 0.18 + speed / 200)} />
        </Sequence>,
      );
    }
  }

  const isTunnel = kind === "tunnel" || kind === "tunnelzero";
  const isSky = kind === "asky" || kind === "tfall";
  // トランポリンのマットの場所（中心x, 中心z, 幅, 奥行き）
  const matArea: [number, number, number, number] = kind === "bparty" ? [0, -0.6, 9, 6] : [2.4, 0, 4.2, 6];
  const beach = useBeachTexture();
  const iceGeom = useMemo(() => new RoundedBoxGeometry(0.16, 0.16, 0.16, 3, 0.025), []);

  // 空から落ちていく場面：下から上へ流れる風のすじ（流れる速さと長さは落ちる速さに比例）
  const streaks: React.ReactNode[] = [];
  if (isSky) {
    [0, 1].forEach((lane) => {
      const sp = sim.values[`v${lane}`];
      const hh = sim.values[`h${lane}`];
      // ここまでに流れた量（m）。見やすいよう、実際の速さの 1/4 で流す
      let travel = 0;
      for (let k = 0; k <= f; k++) {
        travel += (sp[k] / 3.6 / fps) * 0.25;
      }
      // tfall は地面に着いたら止める
      const vNow = kind === "tfall" && hh && hh[f] <= 0 ? 0 : sp[f] / 3.6;
      const len = Math.min(6, 0.15 + vNow * 0.02);
      for (let i = 0; i < 36; i++) {
        const H = 14;
        const y = ((random(`sy${lane}-${i}`) * H + travel) % H) - 5;
        const x = (lane === 0 ? -1.35 : 1.35) + (random(`sx${lane}-${i}`) - 0.5) * 2.6;
        const z = (random(`sz${lane}-${i}`) - 0.5) * 4 - 0.5;
        streaks.push(
          <mesh key={`st${lane}-${i}`} position={[x, y, z]}>
            <boxGeometry args={[0.012, len, 0.012]} />
            <meshBasicMaterial color="#ffffff" transparent opacity={vNow < 1 ? 0 : 0.55} />
          </mesh>,
        );
      }
    });
  }

  const rain: React.ReactNode[] = [];
  // 10cmの人の雨：左はふつうの雨粒（細いすじ）、右はソフトボールくらいの水のかたまり（※動きはスロー）
  if (kind === "train") {
    const t = f / fps;
    [0, 1].forEach((lane) => {
      const cx = lane === 0 ? -1.3 : 1.3;
      const n = lane === 0 ? 120 : 14;
      const speedV = lane === 0 ? 9 : 22;
      const H = 7;
      for (let i = 0; i < n; i++) {
        const x = cx + (random(`tr${lane}x${i}`) - 0.5) * 2.4;
        const z = (random(`tr${lane}z${i}`) - 0.5) * 3;
        // 体の真上は、当たる1粒だけにする
        if (Math.abs(x - cx) < 0.35 && Math.abs(z) < 0.35) {
          continue;
        }
        const y = H - ((random(`tr${lane}y${i}`) * H + t * speedV) % H);
        rain.push(
          lane === 0 ? (
            <mesh key={`tr${lane}-${i}`} position={[x, y + 0.1, z]}>
              <boxGeometry args={[0.008, 0.2, 0.008]} />
              <meshBasicMaterial color="#d6ecff" transparent opacity={0.6} />
            </mesh>
          ) : (
            <mesh key={`tr${lane}-${i}`} position={[x, y, z]} scale={[1, 1.25, 1]}>
              <sphereGeometry args={[0.045, 16, 12]} />
              <meshStandardMaterial color="#9fd3ff" transparent opacity={0.55} roughness={0.05} metalness={0.1} />
            </mesh>
          ),
        );
      }
      // 頭に当たる1粒（当たる時刻にちょうど頭の上に来るように落とす）と、はじける水しぶき
      const head = posAt(sim, f, sim.bodies.findIndex((b) => b.part === "head" && b.lane === lane));
      [1.5, 4.2].forEach((hitT, k) => {
        const dtHit = hitT - t;
        const r = lane === 0 ? 0.012 : 0.045;
        if (dtHit > 0 && dtHit < 0.4) {
          rain.push(
            <mesh key={`hd${lane}-${k}`} position={[head[0], head[1] + 0.15 + dtHit * speedV, head[2]]} scale={[1, 1.25, 1]}>
              <sphereGeometry args={[r, 16, 12]} />
              <meshStandardMaterial color="#9fd3ff" transparent opacity={0.7} roughness={0.05} />
            </mesh>,
          );
        }
        if (dtHit <= 0 && dtHit > -0.35) {
          const s = -dtHit / 0.35;
          for (let j = 0; j < 10; j++) {
            const a = (j / 10) * Math.PI * 2;
            const sp = lane === 0 ? 0.08 : 0.5;
            rain.push(
              <mesh key={`sp${lane}-${k}-${j}`} position={[head[0] + Math.cos(a) * sp * s, head[1] + 0.12 + Math.sin(s * Math.PI) * sp * 0.6, head[2] + Math.sin(a) * sp * s]}>
                <sphereGeometry args={[r * 0.35, 8, 8]} />
                <meshBasicMaterial color="#e8f6ff" transparent opacity={0.85 * (1 - s)} />
              </mesh>,
            );
          }
        }
      });
    });
  }

  // 雨：左はゆっくり（秒速8m・短いすじ）、右は空気抵抗ゼロで超高速（見やすいよう秒速40mで表示・長いすじ）
  if (kind === "arain") {
    [0, 1].forEach((lane) => {
      const cx = lane === 0 ? -1.2 : 1.2;
      const speedV = lane === 0 ? 8 : 40;
      const len = lane === 0 ? 0.18 : 1.6;
      const H = 6;
      for (let i = 0; i < 110; i++) {
        const x = cx + (random(`rx${lane}-${i}`) - 0.5) * 2.3;
        const z = (random(`rz${lane}-${i}`) - 0.5) * 3.2;
        const y = H - ((random(`ry${lane}-${i}`) * H + (f / fps) * speedV) % H);
        rain.push(
          <mesh key={`rn${lane}-${i}`} position={[x, y + len / 2, z]}>
            <boxGeometry args={[0.012, len, 0.012]} />
            <meshBasicMaterial color={lane === 0 ? "#cfe6ff" : "#e8f4ff"} transparent opacity={0.7} />
          </mesh>,
        );
      }
      // 地面と体ではじける水しぶき
      for (let i = 0; i < (lane === 0 ? 10 : 26); i++) {
        const seed = `sp${lane}-${i}-${Math.floor(f / 2)}`;
        const onBody = lane === 1 && i % 3 === 0;
        const x = onBody ? cx + (random(`${seed}x`) - 0.5) * 0.5 : cx + (random(`${seed}x`) - 0.5) * 2.3;
        const z = onBody ? (random(`${seed}z`) - 0.5) * 0.4 : (random(`${seed}z`) - 0.5) * 3.2;
        const y = onBody ? 1.15 + random(`${seed}y`) * 0.25 : 0.02;
        rain.push(
          <mesh key={`spl${lane}-${i}`} position={[x, y, z]}>
            <sphereGeometry args={[lane === 0 ? 0.025 : 0.05, 8, 8]} />
            <meshBasicMaterial color="#ffffff" transparent opacity={0.8} />
          </mesh>,
        );
      }
    });
  }
  const fogColor = isTunnel
    ? "#140a05"
    : isRoad
      ? "#b9c7d6"
      : kind === "arain" || kind === "train" || kind === "rwalk" || kind === "rrun"
        ? "#8f9aa8"
        : TINY_KINDS.includes(kind) || TOAST_KINDS.includes(kind) || BLANKET_KINDS.includes(kind)
          ? "#ead9bc"
          : TRAIN_KINDS.includes(kind) || STRAP_KINDS.includes(kind)
            ? "#e6eaf0"
          : "#cfe8ff";
  // 中心付近（tunnelzero）は人がその場でただようので、壁のほうを流して速さを見せる
  const shaftPhase = kind === "tunnelzero" ? frame * 0.9 : 0;
  // 摩擦ゼロの地面は、つるつるの氷のように見せる（摩擦が消えた瞬間から）
  const ice = isFriction
    ? Math.min(1, Math.max(0, (f - offFrame) / 8))
    : 0;
  const iceArea: [number, number, number, number] | null = !isFriction
    ? null
    : sim.kind === "fchaos"
      ? [0, 0, 40, 40]
      : lanesTop
        ? [10.0, 0, 20, 40]
        : [0, -10, 80, 20];

  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          background: isTunnel
            ? "#140a05"
            : isSky
              ? "linear-gradient(180deg, #1f5fbf 0%, #5ea3e8 45%, #cfe6ff 100%)"
              : kind === "elevfall" || kind === "elevsafe" || kind === "elevfloat"
                ? "#2b2e33"
                : kind === "arain" || kind === "train" || kind === "rwalk" || kind === "rrun"
                ? "linear-gradient(180deg, #4d5866 0%, #7d8896 55%, #a3adb9 100%)"
                : BLANKET_KINDS.includes(kind)
                  ? "linear-gradient(180deg, #e9dccb 0%, #e2d2bd 60%, #d6c3a9 100%)"
                : TINY_KINDS.includes(kind) || TOAST_KINDS.includes(kind)
                  ? "linear-gradient(180deg, #f3e6d0 0%, #e9d6b8 60%, #d9c09a 100%)"
                  : TRAIN_KINDS.includes(kind) || STRAP_KINDS.includes(kind)
                    ? "linear-gradient(180deg, #eef1f5 0%, #dfe4ea 100%)"
                : "linear-gradient(180deg, #4a9cff 0%, #8cc8ff 55%, #dff0ff 100%)",
        }}
      />
      <ThreeCanvas width={width} height={height} shadows camera={{ fov: 40, near: 0.1, far: 400 }}>
        <CameraRig cam={cam} width={width} height={height} />
        <fog attach="fog" args={isTunnel ? [fogColor, 6, 34] : kind === "arain" ? [fogColor, 12, 60] : kind === "gold" || kind === "goldgone" ? [fogColor, 160, 600] : [fogColor, 30, 120]} />
        <hemisphereLight args={isTunnel ? ["#ffd2a0", "#3a1a08", 0.9] : ["#dff1ff", "#6a7a4a", 1.1]} />
        {isTunnel ? (
          <>
            <pointLight position={[cam.look[0] + 0.5, cam.look[1] + 2.5, cam.look[2] + 1]} intensity={30} distance={14} color="#ffe2b8" />
            <Shaft y={cam.look[1]} phase={shaftPhase} />
          </>
        ) : null}
        <directionalLight
          position={[cam.look[0] + 6, 12, 8]}
          intensity={2.4}
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-left={-14}
          shadow-camera-right={14}
          shadow-camera-top={14}
          shadow-camera-bottom={-14}
          shadow-camera-near={1}
          shadow-camera-far={60}
          shadow-bias={-0.0004}
        >
          <object3D attach="target" position={[cam.look[0], 0, 0]} />
        </directionalLight>
        {isTunnel || isSky || SLOPE_KINDS.includes(kind) || kind === "elevfall" || kind === "elevsafe" || kind === "elevfloat" ? null : BOUNCE_KINDS.includes(kind) ? (
          // トランポリンのマットの所だけ、地面に穴をあける（へこんだマットが見えるように）
          (() => {
            const [cx, cz, w, d] = matArea;
            const x0 = cx - w / 2;
            const x1 = cx + w / 2;
            const z0 = cz - d / 2;
            const z1 = cz + d / 2;
            const R = 100;
            const pieces: [number, number, number, number][] = [
              [-R, x0, -R, R],
              [x1, R, -R, R],
              [x0, x1, -R, z0],
              [x0, x1, z1, R],
            ];
            return pieces.map(([a0, a1, b0, b1], k) => {
              // 地面の模様（1m のタイル）が、どの切れ端でも同じ大きさ・同じ位置になるように
              const t = ground.clone();
              t.repeat.set((a1 - a0) / 2, (b1 - b0) / 2);
              t.offset.set((((a0 / 2) % 1) + 1) % 1, (((-b1 / 2) % 1) + 1) % 1);
              t.needsUpdate = true;
              return (
                <mesh key={k} position={[(a0 + a1) / 2, 0, (b0 + b1) / 2]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
                  <planeGeometry args={[a1 - a0, b1 - b0]} />
                  <meshStandardMaterial map={t} roughness={0.95} />
                </mesh>
              );
            });
          })()
        ) : (
          <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
            <planeGeometry args={[200, 200]} />
            <meshStandardMaterial map={ground} roughness={0.95} />
          </mesh>
        )}

        {iceArea && ice > 0 ? (
          <mesh position={[iceArea[0], 0.004, iceArea[1]]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
            <planeGeometry args={[iceArea[2], iceArea[3]]} />
            <meshStandardMaterial color="#d6f3ff" transparent opacity={0.62 * ice} roughness={0.08} metalness={0.25} />
          </mesh>
        ) : null}

        {lanesTop ? (
          // レーンの境目
          <mesh position={[sim.kind === "slip" ? 0.95 : sim.kind === "wind" ? -0.25 : 0, 0.005, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[0.06, 40]} />
            <meshBasicMaterial color="#ffffff" transparent opacity={0.8} />
          </mesh>
        ) : null}

        {sim.kind === "jump" ? (
          <mesh position={[0, 1.5, -0.6]}>
            <planeGeometry args={[0.45, 3.0]} />
            <meshBasicMaterial map={heightRuler} transparent />
          </mesh>
        ) : null}

        {sim.kind === "jump"
          ? [-1, 1].map((x, lane) => {
              const top = v(`top${lane}`);
              return top > 0.15 ? (
                <mesh key={lane} position={[x, top, -0.3]}>
                  <boxGeometry args={[0.9, 0.025, 0.025]} />
                  <meshBasicMaterial color={LANE_COLORS[lane]} />
                </mesh>
              ) : null;
            })
          : null}

        {sim.kind === "scale"
          ? [-1, 1].map((x) => (
              <mesh key={x} position={[x, 0.03, 0]} castShadow receiveShadow>
                <boxGeometry args={[0.78, 0.06, 0.78]} />
                <meshStandardMaterial color="#9aa3ad" roughness={0.4} metalness={0.2} />
              </mesh>
            ))
          : null}

        {sim.kind === "slip"
          ? [0.0, 3.2].map((x) => (
              // バナナの皮
              <mesh key={x} position={[x + 0.1, 0.02, 0.1]} rotation={[0, 0.6, 0]} castShadow>
                <torusGeometry args={[0.1, 0.03, 8, 16, Math.PI]} />
                <meshStandardMaterial color="#ffd21a" roughness={0.5} />
              </mesh>
            ))
          : null}

        {sim.kind === "throw" || sim.kind === "athrow" || sim.kind === "aplane" ? (
          <mesh position={[10, 0.006, 1.9]} rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[20, 1.0]} />
            <meshBasicMaterial map={distRuler} transparent />
          </mesh>
        ) : null}

        {isRoad ? (
          <>
            {/* ブレーキをかける線 */}
            <mesh position={[0, 0.006, 0]} rotation={[-Math.PI / 2, 0, 0]}>
              <planeGeometry args={[0.35, 7.5]} />
              <meshBasicMaterial color="#ffffff" />
            </mesh>
            {/* 車線 */}
            {Array.from({ length: 14 }, (_, i) => (
              <mesh key={i} position={[-10 + i * 3, 0.005, 0]} rotation={[-Math.PI / 2, 0, 0]}>
                <planeGeometry args={[1.6, 0.14]} />
                <meshBasicMaterial color="#f2f2f2" />
              </mesh>
            ))}
            {/* タイヤの跡 */}
            {[0, 1].map((lane) => {
              const ci = findIndex(sim, "car", lane);
              const rear = posAt(sim, f, ci)[0] + 1.3;
              const len = Math.max(0, rear - 1.3 + 0.0);
              if (rear <= 1.3) {
                return null;
              }
              const z = lane === 0 ? 1.7 : -1.7;
              return [-0.78, 0.78].map((dz) => (
                <mesh key={`${lane}${dz}`} position={[1.3 + len / 2, 0.007, z + dz]} rotation={[-Math.PI / 2, 0, 0]}>
                  <planeGeometry args={[len, 0.22]} />
                  <meshBasicMaterial color="#141414" transparent opacity={0.7} />
                </mesh>
              ));
            })}
          </>
        ) : null}

        {sim.bodies.map((b, i) => {
          const pos = posAt(sim, f, i);
          const quat = quatAt(sim, f, i);
          if (b.shape === "part") {
            const color =
              b.look === "shirt"
                ? shirtColor(sim, b.doll ?? 0, b.lane)
                : b.look === "skin"
                  ? SKIN
                  : b.look === "shoe"
                    ? SHOE
                    : PANTS;
            if (GIANT_KINDS.includes(sim.kind) && b.lane === 1) {
              // 巨人：計算はふつうの大きさ。足もとを中心に10倍に大きくして描く
              return (
                <group key={i} position={[GIANT_X[sim.kind][1], 0, 0]} scale={GIANT}>
                  <PersonPart part={b.part!} size={b.size} color={color} pos={pos} quat={quat} />
                </group>
              );
            }
            return <PersonPart key={i} part={b.part!} size={b.size} color={color} pos={pos} quat={quat} closed={BLANKET_KINDS.includes(sim.kind)} />;
          }
          if (b.shape === "ice") {
            return (
              <mesh key={i} position={pos} quaternion={quat} geometry={iceGeom} castShadow>
                <meshStandardMaterial color="#e8f7ff" roughness={0.08} metalness={0.05} transparent opacity={0.82} />
              </mesh>
            );
          }
          if (b.shape === "egg") {
            return (
              <group key={i} position={pos} quaternion={b.lane === 0 && v("broken0") > 0 ? [0, 0, 0, 1] : quat}>
                <Egg broken={b.lane === 0 && v("broken0") > 0} />
              </group>
            );
          }
          if (b.shape === "barbell") {
            return (
              <group key={i} position={pos} quaternion={quat}>
                <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
                  <cylinderGeometry args={[0.018, 0.018, 1.8, 12]} />
                  <meshStandardMaterial color="#c9ccd2" roughness={0.3} metalness={0.8} />
                </mesh>
                {[-0.72, 0.72].map((x) => (
                  <mesh key={x} position={[x, 0, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
                    <cylinderGeometry args={[0.24, 0.24, 0.12, 32]} />
                    <meshStandardMaterial color="#1d1f24" roughness={0.6} />
                  </mesh>
                ))}
              </group>
            );
          }
          if (b.shape === "coins") {
            return (
              <group key={i} position={pos} quaternion={quat}>
                {[0, 1, 2, 3].map((k) => (
                  <Coin key={k} y={-0.0485 + k * 0.0325} rot={k * 0.7} />
                ))}
              </group>
            );
          }
          if (b.shape === "feather") {
            return (
              <group key={i} position={pos} quaternion={quat}>
                <Feather />
              </group>
            );
          }
          if (b.shape === "plane") {
            return (
              <group key={i} position={pos} quaternion={quat}>
                <PaperPlane color={b.color!} />
              </group>
            );
          }
          if (b.shape === "sphere" && b.color === "beach") {
            return (
              <mesh key={i} position={pos} quaternion={quat} castShadow>
                <sphereGeometry args={[b.size[0] / 2, 32, 24]} />
                <meshStandardMaterial map={beach} roughness={0.3} />
              </mesh>
            );
          }
          if (b.shape === "sphere") {
            return (
              <mesh key={i} position={pos} quaternion={quat} castShadow>
                {/* 遠くからでも見えるよう、見た目は少し大きめに */}
                <sphereGeometry args={[b.size[0] * 0.9, 24, 24]} />
                <meshStandardMaterial color={b.color} roughness={0.35} />
              </mesh>
            );
          }
          if (b.shape === "toast") {
            const [L, d] = [b.size[0], b.size[1]];
            return (
              <group key={i} position={pos} quaternion={quat}>
                {/* 耳（まわりの茶色）と、白い中身（上下の面） */}
                <mesh castShadow receiveShadow>
                  <boxGeometry args={[L, d, L]} />
                  <meshStandardMaterial color="#b9783a" roughness={0.8} />
                </mesh>
                {[1, -1].map((s) => (
                  <mesh key={s} position={[0, (s * d) / 2 + s * 0.0006, 0]} rotation={[-s * Math.PI / 2, 0, 0]}>
                    <planeGeometry args={[L * 0.86, L * 0.86]} />
                    <meshStandardMaterial color="#f3dfb0" roughness={0.9} />
                  </mesh>
                ))}
                {b.color === "butter" ? (
                  <mesh position={[0, d / 2 + 0.0014, 0]} rotation={[-Math.PI / 2, 0, 0]}>
                    <planeGeometry args={[L * 0.72, L * 0.72]} />
                    <meshStandardMaterial color="#ffd23a" roughness={0.25} />
                  </mesh>
                ) : (
                  <mesh position={[0, d / 2 + 0.0014, 0]} rotation={[-Math.PI / 2, 0, 0]}>
                    <circleGeometry args={[L * 0.22, 24]} />
                    <meshStandardMaterial color="#e0263a" roughness={0.5} />
                  </mesh>
                )}
              </group>
            );
          }
          if (b.shape === "mat") {
            // マット：板の上の面までの高さで描く（沈むとうすくなる）
            const top = Math.max(0.05, pos[1] + 0.03);
            return (
              <group key={i}>
                <mesh position={[pos[0], top / 2, pos[2]]} castShadow receiveShadow>
                  <boxGeometry args={[b.size[0], top, b.size[2]]} />
                  <meshStandardMaterial color="#2f6fd6" roughness={0.75} />
                </mesh>
                <mesh position={[pos[0], top + 0.002, pos[2]]} rotation={[-Math.PI / 2, 0, 0]}>
                  <planeGeometry args={[b.size[0] - 0.08, b.size[2] - 0.08]} />
                  <meshStandardMaterial color="#3f80e6" roughness={0.8} />
                </mesh>
              </group>
            );
          }
          if (b.shape === "platform") {
            return (
              <mesh key={i} position={pos} quaternion={quat} castShadow receiveShadow>
                <boxGeometry args={b.size} />
                <meshStandardMaterial color="#f4f6f8" roughness={0.3} />
              </mesh>
            );
          }
          if (b.shape === "car" && GIANT_KINDS.includes(sim.kind) && b.lane === 1) {
            // 巨人の世界の車（1/10）を、巨人といっしょに10倍にして描く。つぶれた車は低く平らに
            const ci = sim.bodies.slice(0, i).filter((x) => x.shape === "car" && x.lane === 1).length;
            const cr = sim.values[`crush${ci}`]?.[f] ?? 0;
            return (
              <group key={i} position={[GIANT_X[sim.kind][1], 0, 0]} scale={GIANT}>
                <group position={[pos[0], pos[1] - 0.07 * 0.55 * cr, pos[2]]} quaternion={quat} scale={[0.1, 0.1 * (1 - 0.55 * cr), 0.1 * (1 + 0.12 * cr)]}>
                  <Car color={cr > 0 ? "#cfcfd4" : "#e8e8e8"} />
                </group>
              </group>
            );
          }
          if (b.shape === "car") {
            return (
              <group key={i} position={pos} quaternion={quat}>
                <Car color={b.color!} />
              </group>
            );
          }
          if (b.shape === "box") {
            return (
              <group key={i} position={pos} quaternion={quat}>
                <mesh castShadow receiveShadow>
                  <boxGeometry args={b.size} />
                  <meshStandardMaterial color={b.color} roughness={0.85} />
                </mesh>
                {/* ガムテープ（段ボール箱だけ） */}
                {b.color === "#c8925a" ? (
                  <mesh position={[0, b.size[1] / 2 + 0.002, 0]}>
                    <boxGeometry args={[b.size[0] + 0.004, 0.004, 0.16]} />
                    <meshStandardMaterial color="#d9b77c" roughness={0.6} />
                  </mesh>
                ) : null}
              </group>
            );
          }
          if (b.shape === "wall") {
            return (
              <mesh key={i} position={pos} quaternion={quat} castShadow receiveShadow>
                <boxGeometry args={b.size} />
                <meshStandardMaterial color="#d8cbb8" roughness={0.9} />
              </mesh>
            );
          }
          if (b.shape === "ladder") {
            const L = b.size[1];
            return (
              <group key={i} position={pos} quaternion={quat}>
                {[-0.24, 0.24].map((z) => (
                  <mesh key={z} position={[0, 0, z]} castShadow>
                    <boxGeometry args={[0.06, L, 0.06]} />
                    {/* 柱は左上の色見本と同じ色（赤＝いまの地球、青＝摩擦ゼロ） */}
                    <meshStandardMaterial color={LANE_COLORS[b.lane]} roughness={0.35} metalness={0.3} />
                  </mesh>
                ))}
                {Array.from({ length: 7 }, (_, k) => (
                  <mesh key={k} position={[0, -L / 2 + 0.35 + k * 0.38, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow>
                    <cylinderGeometry args={[0.02, 0.02, 0.48, 10]} />
                    <meshStandardMaterial color="#aeb4bd" roughness={0.35} metalness={0.6} />
                  </mesh>
                ))}
              </group>
            );
          }
          if (b.shape === "cone") {
            return (
              <group key={i} position={pos} quaternion={quat}>
                <Cone />
              </group>
            );
          }
          return null;
        })}
        {GIANT_KINDS.includes(kind) ? (
          // 大きさの目安：ふつうの乗用車（長さ4m）
          <group position={[GIANT_X[kind][0] - (kind === "gstand" ? 3.4 : 2.6), 0.7, kind === "gstand" ? 0.8 : -1.6]} rotation={[0, kind === "gstand" ? 0.5 : 0, 0]}>
            <Car color="#e8e8e8" />
          </group>
        ) : null}
        {GIANT_KINDS.includes(kind) ? <GiantTown /> : null}
        {kind === "epack" ? <PackElevator full={v("full")} t={f / fps} /> : null}
        {BLANKET_KINDS.includes(kind) ? <ClothMesh sim={sim} f={f} look={BLANKETS[kind].look} /> : null}
        {BLANKET_KINDS.includes(kind) ? <Bedroom /> : null}
        {GIANT_KINDS.includes(kind) ? <GiantDust sim={sim} f={f} /> : null}
        {HEAVY_KINDS.includes(kind) ? <HeavyAirHaze sim={sim} f={f} /> : null}
        {kind === "tworld" ? <TinyProps /> : null}
        {kind === "rwalk" || kind === "rrun" ? <RainStreet sim={sim} f={f} /> : null}
        {kind === "elevfall" || kind === "elevsafe" || kind === "elevfloat" ? (
          <ElevatorCar fall={v("fall")} snapped={f >= Math.round((ELEV.snap / (kind === "elevfloat" ? ELEV.slow : 1)) * fps)} t={f / fps} />
        ) : null}
        {STRAP_KINDS.includes(kind)
          ? [-1.4, 1.4].map((x0, lane) => {
              const gx = sim.values[`ax${lane}`][f];
              const gy = sim.values[`ay${lane}`][f];
              const gz = sim.values[`az${lane}`][f];
              return <TrainCar key={lane} x0={x0} pos={v(`pos${lane}`)} grip={Number.isNaN(gx) ? null : [gx, gy, gz]} />;
            })
          : null}
        {TRAIN_KINDS.includes(kind)
          ? [-1.4, 1.4].map((x0, lane) => {
              const take = sim.values[`take${lane}`][f];
              const land = sim.values[`land${lane}`][f];
              return (
                <group key={lane}>
                  <TrainCar x0={x0} pos={v(`pos${lane}`)} />
                  {/* 跳んだ位置（赤い線）と、着地した位置（青い線） */}
                  {!Number.isNaN(take) ? (
                    <mesh position={[take, 0.006, 0.45]} rotation={[-Math.PI / 2, 0, 0]}>
                      <planeGeometry args={[0.06, 0.7]} />
                      <meshBasicMaterial color="#ff2d2d" />
                    </mesh>
                  ) : null}
                  {!Number.isNaN(land) ? (
                    <mesh position={[land, 0.007, 0.45]} rotation={[-Math.PI / 2, 0, 0]}>
                      <planeGeometry args={[0.06, 0.7]} />
                      <meshBasicMaterial color="#2f8bff" />
                    </mesh>
                  ) : null}
                </group>
              );
            })
          : null}
        {kind === "gold" || kind === "goldgone" ? <GoldCube gone={v("gone")} t={f / fps} /> : null}
        {kind === "ice"
          ? [-1.0, 1.0].map((x0, lane) => {
              const sp = sim.values[`splash${lane}`]?.[f] ?? -1;
              const since = sp < 0 ? 99 : f / fps - sp;
              return (
                <group key={lane}>
                  {/* 水 */}
                  <mesh position={[x0, TANK.level / 2, TANK.z]}>
                    <boxGeometry args={[TANK.w - 0.04, TANK.level, TANK.d - 0.04]} />
                    <meshStandardMaterial color="#3d9bff" transparent opacity={0.32} roughness={0.1} depthWrite={false} />
                  </mesh>
                  {/* 水面 */}
                  <mesh position={[x0, TANK.level, TANK.z]} rotation={[-Math.PI / 2, 0, 0]}>
                    <planeGeometry args={[TANK.w - 0.04, TANK.d - 0.04]} />
                    <meshStandardMaterial color="#9fd3ff" transparent opacity={0.45} roughness={0.05} depthWrite={false} side={THREE.DoubleSide} />
                  </mesh>
                  {/* ガラスのふち */}
                  {[
                    [x0 - TANK.w / 2, TANK.z - TANK.d / 2],
                    [x0 + TANK.w / 2, TANK.z - TANK.d / 2],
                    [x0 - TANK.w / 2, TANK.z + TANK.d / 2],
                    [x0 + TANK.w / 2, TANK.z + TANK.d / 2],
                  ].map(([x, z], k) => (
                    <mesh key={k} position={[x, TANK.h / 2, z]}>
                      <boxGeometry args={[0.025, TANK.h, 0.025]} />
                      <meshStandardMaterial color="#dfe9f2" roughness={0.2} />
                    </mesh>
                  ))}
                  {[TANK.z - TANK.d / 2, TANK.z + TANK.d / 2].map((z, k) => (
                    <mesh key={`t${k}`} position={[x0, TANK.h, z]}>
                      <boxGeometry args={[TANK.w, 0.025, 0.025]} />
                      <meshStandardMaterial color="#dfe9f2" roughness={0.2} />
                    </mesh>
                  ))}
                  <mesh position={[x0, TANK.h / 2, TANK.z]}>
                    <boxGeometry args={[TANK.w, TANK.h, TANK.d]} />
                    <meshStandardMaterial color="#ffffff" transparent opacity={0.08} roughness={0.05} depthWrite={false} />
                  </mesh>
                  {/* 水しぶき */}
                  {since < 0.45
                    ? Array.from({ length: 14 }, (_, k) => {
                        const a = (k / 14) * Math.PI * 2;
                        const s2 = since / 0.45;
                        return (
                          <mesh key={`sp${k}`} position={[x0 + Math.cos(a) * 0.25 * s2, TANK.level + Math.sin(s2 * Math.PI) * 0.25 * (0.6 + (k % 3) * 0.2), TANK.z + Math.sin(a) * 0.15 * s2]}>
                            <sphereGeometry args={[0.018, 8, 8]} />
                            <meshBasicMaterial color="#e8f6ff" transparent opacity={0.9 * (1 - s2)} />
                          </mesh>
                        );
                      })
                    : null}
                </group>
              );
            })
          : null}
        {BOUNCE_KINDS.includes(kind) ? (
          <TrampMat sim={sim} f={f} lane={1} area={matArea} />
        ) : null}
        {trails}
        {streaks}
        {rain}
      </ThreeCanvas>
      {bare ? null : overlays}
      {bare ? null : sounds}
      {BOUNCE_KINDS.includes(kind) && !bare ? <BounceSounds sim={sim} offset={offset} /> : null}
      {(kind === "elevfall" || kind === "elevsafe" || kind === "elevfloat") && !bare
        ? [
            { at: ELEV.snap / (kind === "elevfloat" ? ELEV.slow : 1), file: "sfx/clack.wav", vol: 0.45 },
            ...(kind === "elevfall"
              ? [{ at: ELEV.snap + Math.sqrt((2 * ELEV.height) / 9.8), file: "sfx/impact.wav", vol: 0.5 }]
              : kind === "elevsafe"
                ? [{ at: ELEV.snap + 0.4, file: "sfx/thud2.wav", vol: 0.3 }]
                : []),
          ].map(({ at, file, vol }) => {
            const from = Math.round(at * fps) - offset;
            return from >= 0 ? (
              <Sequence key={file} from={from} durationInFrames={30}>
                <Audio src={staticFile(file)} volume={vol} />
              </Sequence>
            ) : null;
          })
        : null}
      {kind === "goldgone" && Math.round(GOLD_GONE * fps) - offset >= 0 ? (
        <Sequence from={Math.round(GOLD_GONE * fps) - offset} durationInFrames={40}>
          <Audio src={staticFile("sfx/sparkle.wav")} volume={0.35} />
        </Sequence>
      ) : null}
      {kind === "ice"
        ? [0, 1].flatMap((lane) => {
            // 氷が水に入るたびに「チャポン」（記録された時刻が変わったフレーム）
            const sp = sim.values[`splash${lane}`];
            const out: React.ReactNode[] = [];
            for (let k = Math.max(1, offset); k < sim.frames; k++) {
              if (sp[k] !== sp[k - 1] && sp[k] > 0) {
                out.push(
                  <Sequence key={`pl${lane}-${k}`} from={k - offset} durationInFrames={15}>
                    <Audio src={staticFile("sfx/plop.wav")} volume={0.22} />
                  </Sequence>,
                );
              }
            }
            return out;
          })
        : null}
      {kind === "arain" || kind === "train" ? <Audio src={staticFile("sfx/rain.wav")} volume={0.3} loop /> : null}
      {kind === "train"
        ? [1.5, 4.2].map((h) => {
            const from = Math.round(h * fps) - offset;
            return from >= 0 ? (
              <Sequence key={h} from={from} durationInFrames={20}>
                <Audio src={staticFile("sfx/thud2.wav")} volume={0.22} />
              </Sequence>
            ) : null;
          })
        : null}
      {isSky ? <Audio src={staticFile("sfx/whoosh.wav")} volume={0.12} /> : null}
    </AbsoluteFill>
  );
};
